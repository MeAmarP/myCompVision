# -*- coding: utf-8 -*-
"""
Created on Mon Apr  8 12:08:42 2019

@author: apotdar
"""
import time
from tqdm import tqdm

FrameLen = 10
FrameNum = 0

pbar = tqdm(total=FrameLen,leave=False,unit='Frame')
while True:
    if FrameNum < FrameLen:
#        print('I Am Recording\n')
        FrameNum += 1 
        pbar.update(1)
        pbar.refresh()
        time.sleep(0.2)
    else:
        FrameNum=0
        pbar.n = 0
#        pbar.refresh()

        
#from tqdm import tqdm
#from time import sleep
#pbar = tqdm(range(100))
#pbar.update(50)
#pbar.refresh()
#sleep(2)
#pbar.n = 10 #check this
#pbar.refresh() #check this
#sleep(2)
#pbar.update(30)