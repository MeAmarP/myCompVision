# -*- coding: utf-8 -*-
"""
A Simple script to record the Video 
Created on Fri Apr  5 15:47:05 2019
@author: apotdar
"""

import picamera
from io import BytesIO

#==============================================================================
# Record Video to File
#==============================================================================
def recordVideoFile(CamResolution=(640,480),filepath='my_video.h264',RecordTime=10):
    camera = picamera.PiCamera()
    camera.resolution = CamResolution
    camera.start_recording(filepath)
    camera.wait_recording(RecordTime)
    camera.stop_recording()

#==============================================================================
# Record Video to Stream
#==============================================================================
def recordVideoStream(CamResolution=(640,480),RecordTime=10):
    stream = BytesIO()
    camera = picamera.PiCamera()
    camera.resolution = CamResolution
    camera.start_recording(stream, format='h264', quality=20)
    camera.wait_recording(RecordTime)
    camera.stop_recording()
    