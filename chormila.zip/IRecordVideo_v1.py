#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  IRecordVideo_v1.py
#  
#  Copyright 2019 AMAR P <amar.potdar@capgemini.com>

# -*- coding: utf-8 -*-
"""
A Simple script to record the Video 
Created on Fri Apr  5 15:47:05 2019
@author: apotdar
"""
import time
import picamera
import picamera.array

from io import BytesIO
import numpy as np

#==============================================================================
# Record Video to File
#==============================================================================
def recordVideoFile(CamResolution=(640,480),filepath='my_video.h264',RecordTime=10):
    camera = picamera.PiCamera()
    camera.resolution = CamResolution
    camera.rotation = 180
    camera.start_recording(filepath)
    camera.wait_recording(RecordTime)
    camera.stop_recording()

#==============================================================================
# Record Video to Stream
#==============================================================================
def recordVideoStream(CamResolution=(640,480),RecordTime=10):
    stream = BytesIO()
    camera = picamera.PiCamera()
    camera.framerate = 4
    camera.resolution = CamResolution
    camera.rotation = 180
    camera.start_recording(stream, format='h264', quality=20)
    camera.wait_recording(RecordTime)
    camera.stop_recording()
    data = np.fromstring(stream.getvalue(), dtype=np.uint8)
    return data
    
def recordUnencodedStream(CamResolution=(640,480)):
    camera = picamera.PiCamera()
    with picamera.array.PiRGBArray(camera) as stream:
        camera.resolution = CamResolution	
        camera.start_preview()
        time.sleep(2)
        camera.capture(stream, 'rgb')
        # Show size of RGB data
        print(stream.array.shape)

    
def main():
	#recordVideoFile()
    recordUnencodedStream()    
    
    
if __name__ == '__main__':
	main()

