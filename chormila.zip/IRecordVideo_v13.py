#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  IRecordVideo_v12.py
#  
#  Copyright 2019 AMAR P <amar.potdar@capgemini.com>

from tensorflow.keras.applications.mobilenet_v2 import MobileNetV2, preprocess_input

import numpy as np

from picamera.array import PiRGBArray
from picamera import PiCamera

import cv2

import time
from tqdm import tqdm
#import matplotlib.pyplot as plt

FRAME_LEN = 40

def initFeatureModel():
    """
    Build and Init Feature/Base Model, will be used for feature extraction from
    images
    """
    featureModel = MobileNetV2(weights='imagenet',
                             include_top=False,
                             pooling='avg')
    return featureModel
    
def extractFeature(model, img):
    """
    This will extract feature from the given frame using InceptionV3 as Base
    model
    """
    img = cv2.resize(img,(224,224),interpolation = cv2.INTER_CUBIC)
#    img = (img / 255.).astype(np.float32)
    x = np.expand_dims(img, axis=0)
    x = preprocess_input(x)
    # Get the prediction.
    features = model.predict(x)
    features = features[0]
    return features


CamResolution=(640,480)

camera = PiCamera()
camera.resolution = CamResolution
camera.rotation = 180
camera.framerate = 4

rawCapture = PiRGBArray(camera,size=CamResolution)
#time.sleep(0.1)
featModel = initFeatureModel()

featureVect=[]
frameNum = 0
pbar = tqdm(total=FRAME_LEN,leave=False,unit='frame')

start = time.time()
for frame in camera.capture_continuous(rawCapture,format='rgb',use_video_port=True):
    print('Hey,I Am Watching (^.^)\n')
    if frameNum < FRAME_LEN:
        img = frame.array
        pbar.update(1)
        pbar.refresh()
        #print('[FrameNumber, Frame Shape]= ',frameNum,img.shape)
        feature = extractFeature(featModel,img)
        featureVect.append(feature)
        rawCapture.truncate(0)
        frameNum += 1
    else:
        print('Hey,I Am Predicting (-.-) ')
        rawCapture.truncate(0)
        pbar.n = 0
        print('Time to 40 frame Extract = ', time.time()-start)
        npfeatureVect = np.array(featureVect)
#        print(npfeatureVect.shape)
        featureVect=[]
        frameNum = 0

        
        
    
    
    


