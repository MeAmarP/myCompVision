
# -*- coding: utf-8 -*-
#
#  blinky.py
#  
#  Copyright 2019  <pi@robo_104>



def WarnBuzzer():
    import RPi.GPIO as GPIO
    import time
    BUZZER_PIN = 8
    
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BOARD)
    GPIO.setup(BUZZER_PIN,GPIO.OUT,initial = GPIO.LOW)

    for _ in range(5):
        GPIO.output(BUZZER_PIN,GPIO.LOW)
        time.sleep(0.3) #300ms
        GPIO.output(BUZZER_PIN,GPIO.HIGH)
        time.sleep(0.3) #300ms
    GPIO.cleanup()
    
def notifyActivity_SMS():
    import requests
    url = "https://www.fast2sms.com/dev/bulk"
    querystring = {"authorization":"17VQSGeXHPfNlcR4BnFdJvWATgoMq2wbaj6I0uKOpy3ki5hsCL2tfMjGa5lNLDYvWyheFXi0UuK3cr4x",
               "sender_id":"FSTSMS",
               "message":"Warning! Suspicious Activity@CAM-007",
               "language":"english",
               "route":"p",
               "numbers":"9860200223,9657992822"}
    headers ={'cache-control': "no-cache"}
    response = requests.request("GET", url, headers=headers, params=querystring)
    print(response.text)            


if __name__ == '__main__':
    notifyActivity_SMS()
