# -*- coding: utf-8 -*-
"""
Created on Tue Feb  5 17:49:25 2019

@author: apotdar
"""

import cv2
import numpy as np

MainImg = cv2.imread("FEB4_pics/NW0.jpg",0)
#tempImg = cv2.imread("FEB4_pics/tempNW0.jpg",0)

#orb = cv2.ORB_create()

kp1, des1 = orb.detectAndCompute(MainImg,None)
#kp2, des2 = orb.detectAndCompute(tempImg,None)

fin_keypts = cv2.drawKeypoints(MainImg,kp1,(0,255,0))
#bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
#
#matches = bf.match(des1,des2)
#matches = sorted(matches, key = lambda x:x.distance)
#
#img3 = cv2.drawMatches(MainImg,kp1,tempImg,kp2,matches[:10],None, flags=2)
#
cv2.imshow('ResultImg', fin_keypts)
cv2.waitKey()
