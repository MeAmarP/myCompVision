# -*- coding: utf-8 -*-
"""
Created on Wed Feb  6 12:11:17 2019

@author: apotdar
"""

import numpy as np
import cv2
from cv2 import aruco

NoOfMarkers = 3
aruco_dict = aruco.getPredefinedDictionary(aruco.DICT_5X5_100)
fileName = ''

for num in range(NoOfMarkers):
    img = aruco.drawMarker(aruco_dict,num,300)
    fileName = 'img' + str(num)+'.jpg'
    cv2.imwrite(fileName,img)




