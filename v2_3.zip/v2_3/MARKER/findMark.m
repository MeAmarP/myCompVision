%file: 
%Author:
%Version: V2.00
%Date: 10/08/2018
%Obj:%-Identify Objects in the Image 
     %-find shape,size and number of objects 

clc     
close all;
clear;
tic;
 
imgPath = 'JAN31_newmark\v3.jpg';

ogimg = imread(imgPath); 
Img_info = imfinfo(imgPath);

%Convert 24-Bit(RGB) to 8-Bit(Grayscale) Image
GreyImg = rgb2gray(ogimg); 

BinImg = im2bw(GreyImg);
iBinImg = ~BinImg;
% se = strel('disk',2);
% iBinImg = imdilate(iBinImg,se);
    
% [LabelMicro1Img , numObj] = bwlabel(BinMicro1Img);
% subplot(122);
imshow(iBinImg, []);
axis on;
axis image;
title('Processed Image');

GetObject = regionprops(iBinImg, 'all');
AllExtent = GetObject.Extent;
hold on
for i = 1:length(GetObject)
    
    %plot(GetObject(i).Centroid(1),GetObject(i).Centroid(2),num2str(i),'color','r')
    text(GetObject(i).Centroid(1),GetObject(i).Centroid(2),num2str(i),'color','r')
    rectangle('Position',GetObject(i).BoundingBox,'EdgeColor','g')
end


hold off
execTime = toc;
fprintf('Total Execution Time: %.4f Seconds\n', execTime);

