# -*- coding: utf-8 -*-
"""
Created on Tue Feb  5 12:13:59 2019

@author: apotdar
"""

import cv2
import numpy as np


ImgPath = "FEB4_pics/NW1.jpg"
MainImg = cv2.imread(ImgPath)
GrayImg = cv2.cvtColor(MainImg,cv2.COLOR_BGR2GRAY)

_,BinImg = cv2.threshold(GrayImg,127,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)

(_,contours,hierarchy)=cv2.findContours(BinImg.copy(),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

AllBBox     = []

CircleCenters   = []
CircleBBox = []
CircleArea = []

StarCenters     = []
StarBBox = []
StarArea = []
TriAngCenters   = []
TriAngBBox = []
TriAngArea = []

Allareas = []
for num,cnt in enumerate(contours):
    area = cv2.contourArea(cnt)
    if area > 25:
        M = cv2.moments(contours[num])
        if M["m00"] != 0:
            cx = int(M["m10"] / M["m00"])
            cy = int(M["m01"] / M["m00"])
            cv2.putText(MainImg,
                str(num),
                (cx,cy),
                cv2.FONT_HERSHEY_SIMPLEX,0.3,
                (128,255,255),1)        
            
            Allareas.append(area)
            x,y,w,h = cv2.boundingRect(cnt)
            AllBBox.append([x,y,w,h,num])
            rectArea = w*h
            extent = float(area/rectArea)
            if extent > 0.65 and extent <0.85:
                cv2.putText(MainImg,
                            'o',
                            (cx,cy),
                            cv2.FONT_HERSHEY_SIMPLEX,1,
                            (255,0,255),1)
                CircleCenters.append([cx,cy])
                CircleBBox.append([x,y,w,h])
                CircleArea.append(area)                
            elif extent > 0.2 and extent <0.4:
                cv2.putText(MainImg,
                            '*',
                            (cx,cy),
                            cv2.FONT_HERSHEY_SIMPLEX,1,
                            (0,0,255),1)
                StarCenters.append([cx,cy])
                StarBBox.append([x,y,w,h])
                StarArea.append(area)
            elif extent > 0.4 and extent < 0.6:
                cv2.putText(MainImg,
                            '^',
                            (cx,cy),
                            cv2.FONT_HERSHEY_SIMPLEX,1,
                            (0,0,255),1)
                TriAngCenters.append([cx,cy])
                TriAngBBox.append([x,y,w,h])
                TriAngArea.append(area)

CircleCenters = np.array(CircleCenters)
StarCenters = np.array(StarCenters)
TriAngCenters = np.array(TriAngCenters)

CircleBBox = np.array(CircleBBox)
StarBBox = np.array(StarBBox)
TriAngBBox = np.array(TriAngBBox)

fin_CBbox = np.diff(CircleBBox[:,[0,2,3]],axis=0)
fin_SBbox = np.diff(StarBBox[:,[0,2,3]],axis=0)
fin_TBbox = np.diff(TriAngBBox[:,[0,2,3]],axis=0)

FindCBbox = np.flatnonzero(((np.abs(fin_CBbox)) <=1).all(axis=1))
FindSBbox = np.flatnonzero(((np.abs(fin_SBbox)) <=1).all(axis=1))
FindTBbox = np.flatnonzero(((np.abs(fin_TBbox)) <=1).all(axis=1))

if len(FindCBbox) >=1: print('Found CircleMark at: \n',CircleCenters[FindCBbox[:],:])
if len(FindSBbox) >=1: print('Found StarMark at: \n',StarCenters[FindSBbox[:],:])
if len(FindTBbox) >=1: print('Found TriAngMark at: \n', TriAngCenters[FindTBbox[:],:])


cv2.imshow('MainImg',MainImg)
#cv2.imshow('GrayImg',GrayImg)
#cv2.imshow('ThreshImage',thrImg)
cv2.imshow('BinImg',BinImg)
#cv2.imshow('Blur Img', BlurImg)




