# -*- coding: utf-8 -*-
"""
Created on Mon Feb  4 14:48:50 2019

@author: apotdar
"""

import cv2
import numpy as np


ImgPath = "FEB4_pics/NW10.jpg"
MainImg = cv2.imread(ImgPath)
GrayImg = cv2.cvtColor(MainImg,cv2.COLOR_BGR2GRAY)
#thrImg = cv2.adaptiveThreshold(GrayImg,127,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,\
#            cv2.THRESH_BINARY_INV,11,2)
#BlurImg = cv2.GaussianBlur(GrayImg, (5, 5), 0)
_,BinImg = cv2.threshold(GrayImg,127,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
#edges = cv2.Canny(GrayImg,220,255)

(_,contours,hierarchy)=cv2.findContours(BinImg.copy(),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

AllBBox     = []
AllSolid    = []
CircleCenters   = []
StarCenters     = []
TriAngCenters   = []
for num,cnt in enumerate(contours):

#    cv2.drawContours(MainImg, contours[num], -1, (0,255,0), 1)
    M = cv2.moments(contours[num])
    if M["m00"] != 0:
        cx = int(M["m10"] / M["m00"])
        cy = int(M["m01"] / M["m00"])
        cv2.putText(MainImg,
            str(num),
            (cx,cy),
            cv2.FONT_HERSHEY_SIMPLEX,0.3,
            (128,255,255),1)        
        area = cv2.contourArea(cnt)
#        hull = cv2.convexHull(cnt)
#        hull_area = cv2.contourArea(hull)
#        solidity = float(area)/hull_area
#        AllSolid.append([solidity,num])
#        strSolidity = str(format(solidity,'.2f'))
        x,y,w,h = cv2.boundingRect(cnt)
        AllBBox.append([x,y,w,h,num])
        rectArea = w*h
        extent = float(area/rectArea)
        #and solidity >= 0.96 and solidity < 1.0
        if extent > 0.65 and extent <0.85:
            cv2.putText(MainImg,
                        'o',
                        (cx,cy),
                        cv2.FONT_HERSHEY_SIMPLEX,1,
                        (255,0,255),1)
            CircleCenters.append(cx)
#            cv2.putText(MainImg,
#                        strSolidity,
#                        (cx,cy),
#                        cv2.FONT_HERSHEY_SIMPLEX,0.5,
#                        (0,255,255),1)
        elif extent > 0.2 and extent <0.4:
#        elif extent > 0.2 and extent <0.4 and solidity >= 0.34 and solidity <= 0.38:
            cv2.putText(MainImg,
                        '*',
                        (cx,cy),
                        cv2.FONT_HERSHEY_SIMPLEX,1,
                        (0,0,255),1)
            StarCenters.append(cx)
#            cv2.putText(MainImg,
#                        strSolidity,
#                        (cx,cy),
#                        cv2.FONT_HERSHEY_SIMPLEX,0.5,
#                        (0,255,255),1)            
        elif extent > 0.4 and extent < 0.6:
#        elif extent > 0.4 and extent < 0.6 and solidity >= 0.90 and solidity < 1.0:
            cv2.putText(MainImg,
                        '^',
                        (cx,cy),
                        cv2.FONT_HERSHEY_SIMPLEX,1,
                        (0,0,255),1)
            TriAngCenters.append(cx)
#            cv2.putText(MainImg,
#                        strSolidity,
#                        (cx,cy),
#                        cv2.FONT_HERSHEY_SIMPLEX,0.5,
#                        (0,255,255),1)

#        cv2.putText(MainImg,
#            str(num),
#            (cx,cy),
#            cv2.FONT_HERSHEY_SIMPLEX,1,
#            (0,0,255),1)
#    cv2.drawContours(MainImg, contours[num], -1, (0,255,0), 1)


cv2.imshow('MainImg',MainImg)
#cv2.imshow('GrayImg',GrayImg)
#cv2.imshow('ThreshImage',thrImg)
cv2.imshow('BinImg',BinImg)
#cv2.imshow('Blur Img', BlurImg)
cv2.waitKey()

