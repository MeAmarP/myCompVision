# -*- coding: utf-8 -*-
"""
Created on Tue Feb  5 12:13:59 2019

@author: apotdar
"""

import cv2
import numpy as np
import time

ImgPath = "FEB4_pics/NW1.jpg"

startTime = time.time()
MainImg = cv2.imread(ImgPath)
GrayImg = cv2.cvtColor(MainImg,cv2.COLOR_BGR2GRAY)
_,BinImg = cv2.threshold(GrayImg,127,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)

(_,contours,hierarchy)=cv2.findContours(BinImg.copy(),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

AllBBox     = []
Allareas = []

CircleCenters= []
CircleBBox= []

StarCenters= []
StarBBox= []

TriAngCenters= []
TriAngBBox= []


for num,cnt in enumerate(contours):
    area = cv2.contourArea(cnt)
    if area > 10:
        M = cv2.moments(contours[num])
        if M["m00"] != 0:
            cx = int(M["m10"] / M["m00"])
            cy = int(M["m01"] / M["m00"])
                   
            Allareas.append(area)
            x,y,w,h = cv2.boundingRect(cnt)
            AllBBox.append([x,y,w,h,num])
            rectArea = w*h
            extent = float(area/rectArea)
            cv2.putText(MainImg,
                        str(format(extent,'.2f')),
                        (cx,cy),
                        cv2.FONT_HERSHEY_SIMPLEX,0.3,
                        (128,255,255),1) 
            if extent > 0.65 and extent <0.85:
                CircleCenters.append([cx,cy])
                CircleBBox.append([x,y,w,h])                
            elif extent > 0.2 and extent <0.39:
                StarCenters.append([cx,cy])
                StarBBox.append([x,y,w,h])
            elif extent > 0.39 and extent < 0.65:
                TriAngCenters.append([cx,cy])
                TriAngBBox.append([x,y,w,h])

CircleCenters = np.array(CircleCenters)
StarCenters = np.array(StarCenters)
TriAngCenters = np.array(TriAngCenters)

CircleBBox = np.array(CircleBBox)
StarBBox = np.array(StarBBox)
TriAngBBox = np.array(TriAngBBox)

CircleBBox = CircleBBox[np.argsort(CircleBBox[:,0]),:]
StarBBox = StarBBox[np.argsort(StarBBox[:,0]),:]
TriAngBBox = TriAngBBox[np.argsort(TriAngBBox[:,0]),:]

fin_CBbox = np.diff(CircleBBox[:,[0,2,3]],axis=0)
fin_SBbox = np.diff(StarBBox[:,[0,2,3]],axis=0)
fin_TBbox = np.diff(TriAngBBox[:,[0,2,3]],axis=0)


FindCBbox = np.flatnonzero(((np.abs(fin_CBbox)) <=11).all(axis=1))
FindSBbox = np.flatnonzero(((np.abs(fin_SBbox)) <=11).all(axis=1))
FindTBbox = np.flatnonzero(((np.abs(fin_TBbox)) <=11).all(axis=1))


#tpl_CirCenter = tuple(map(tuple,CircleCenters[FindCBbox[:],:]))
#tpl_StarCenter = tuple(map(tuple,StarCenters[FindSBbox[:],:])) 
#tpl_TriAngCenter = tuple(map(tuple,TriAngCenters[FindTBbox[:],:])) 



tpl_CirBox = tuple(map(tuple,CircleBBox[FindCBbox[:],:2]))
tpl_StarBox = tuple(map(tuple,StarBBox[FindSBbox[:],:2])) 
tpl_TriAngBox = tuple(map(tuple,TriAngBBox[FindTBbox[:],:2])) 
print("\n\nExecution Time: ", time.time()-startTime)
print(tpl_CirBox)
print(tpl_StarBox)
print(tpl_TriAngBox)

for Cmark in tpl_CirBox:
    cv2.putText(MainImg,
                'o',
                Cmark,
                cv2.FONT_HERSHEY_SIMPLEX,1,
                (255,0,255),1)
    
for Smark in tpl_StarBox:
    cv2.putText(MainImg,
                '*',
                Smark,
                cv2.FONT_HERSHEY_SIMPLEX,1,
                (128,0,255),1)    
    
for Tmark in tpl_TriAngBox:
    cv2.putText(MainImg,
                '^',
                Tmark,
                cv2.FONT_HERSHEY_SIMPLEX,1,
                (0,128,255),1)    
    

cv2.imshow(ImgPath,MainImg)
#cv2.imshow('BinImg',BinImg)


