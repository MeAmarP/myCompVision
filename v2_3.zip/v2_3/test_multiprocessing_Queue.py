# -*- coding: utf-8 -*-
"""
# How to use multiprocessing.Queue as a FIFO queue:
Created on Fri Dec 21 12:46:32 2018

@author: apotdar
"""

from multiprocessing.dummy import Pool as ThreadPool
import multiprocessing as mp
from pyvision import pyvision
from pymoto import pymoto
import roboparam


RoboID = 'R111'

mivis = pyvision()
mivis.setMarkHSV(roboparam.VisionPara[RoboID]['MarkHSVUL'],
                 roboparam.VisionPara[RoboID]['MarkHSVLL'])

mivis.setObjHSV(roboparam.VisionPara[RoboID]['ObjHSVUL'],
                roboparam.VisionPara[RoboID]['ObjHSVLL'])

mimoto = pymoto()


manager = mp.Manager()
AllQue = manager.Queue()

#pyvision(AllQue)
Pool = ThreadPool() #NotUsed
#motoPool = ThreadPool()

Pool.map(mivis.run_pyvision,(AllQue,))
Pool.map(mimoto.run_pymoto,(AllQue,))

Pool.close()
Pool.close()

Pool.join()
Pool.join()
