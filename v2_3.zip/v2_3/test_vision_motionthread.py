# -*- coding: utf-8 -*-
"""
Test/main Code for Vision and Motion executio on threads

Created on Fri Jan 11 12:42:49 2019
@author: apotdar
"""
from threading import Thread
from queue import Queue
from pyvision import pyvision
from pymoto import pymoto
import roboparam

RoboID = 'R104'

mivis = pyvision()
mivis.setMarkHSV(roboparam.VisionPara[RoboID]['MarkHSVUL'],
                 roboparam.VisionPara[RoboID]['MarkHSVLL'])

mivis.setObjHSV(roboparam.VisionPara[RoboID]['ObjHSVUL'],
                roboparam.VisionPara[RoboID]['ObjHSVLL'])

mimoto = pymoto()

myQ = Queue(1)

visionThread = Thread(target=mivis.run_pyvision, args=(myQ,))
motoThread = Thread(target=mimoto.run_pymoto, args=(myQ,))

visionThread.start()
motoThread.start()
