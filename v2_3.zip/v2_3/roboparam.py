#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
File: Roboparams.py
Description: Parameters required for configuration of the Robots and it's related
Hardware.
Created on Wed Jan  9 12:57:57 2019

@author: apotdar
"""

#This is default Value, can be updated
MyID = "R111"

#===============================================================================
MotionPara = {
        'R104':
            {'Turn180DutyCycle':    90,
             'Turn180Time':         2.7,
             'Turn10DutyCycle':     50,
             'Turn10Time':          0.40,
             'FwdDutyCycle':        100,
             'FwdTime':             1.5,
             'PickDist':            300
             },
        'R105':
            {'Turn180DutyCycle':90,
             'Turn180Time': 2.7,
             'Turn10DutyCycle':50,
             'Turn10Time':0.30,
             'FwdDutyCycle':100,
             'FwdTime':1.5,
             'PickDist':300
             },
        'R111':
            {'Turn180DutyCycle':90,
             'Turn180Time': 2.7,
             'Turn10DutyCycle':50,
             'Turn10Time':0.40,
             'FwdDutyCycle':100,
             'FwdTime':1.5,
             'PickDist':300
             }
        }


#===============================================================================
VisionPara = {
        'R104':
            {'CameraBright':60,
             
             'ObjHSVLL':[0,50,50],      #Red ObjectHSV Lower Limit
             'ObjHSVUL':[10,255,255],   #Red ObjectHSV Upper Limit
             'MarkHSVLL':[90,90,70],    #Blue MarkerHSV Lower Limit
             'MarkHSVUL':[110,240,240], #Blue MarkerHSV Upper Limit
             
             'ObjColrLL':[0,0,0],       #Red ObjectBGR Lower Limit
             'ObjColrUL':[0,0,0],       #Red ObjectBGR Upper Limit
             'MarkColrLL':[99,90,75],   #Blue MarkerBGR Lower Limit
             'MarkColrUL':[136,124,104],#Blue MarkerBGR Upper Limit
             
             'MarkColor':'B'},
        'R105':
            {'CameraBright':65,
             
             'ObjHSVLL':[0,50,50],      #Red ObjectHSV Lower Limit
             'ObjHSVUL':[10,255,255],   #Red ObjectHSV Upper Limit
             'MarkHSVLL':[2,120,120],   #Orange MarkerHSV Lower Limit
             'MarkHSVUL':[40,216,255],  #Orange MarkerHSV Upper Limit
             
             'ObjColrLL':[0,0,0],       #Red ObjectBGR Lower Limit
             'ObjColrUL':[0,0,0],       #Red ObjectBGR Upper Limit
             'MarkColrLL':[71,100,141], #Orange MarkerBGR Lower Limit
             'MarkColrUL':[100,141,194],#Orange MarkerBGR Upper Limit
             
             'MarkColor':'O'},
        'R111':
            {'CameraBright':70,
             
             'ObjHSVLL':[0,50,50],      #Red ObjectHSV Lower Limit
             'ObjHSVUL':[10,255,255],   #Red ObjectHSV Upper Limit
             'MarkHSVLL':[40,70,70],    #Green MarkerHSV Lower Limit
             'MarkHSVUL':[80,255,255],  #Green MarkerHSV Upper Limit
             
             'ObjColrLL':[0,0,0],       #Red ObjectBGR Lower Limit
             'ObjColrUL':[0,0,0],       #Red ObjectBGR Upper Limit
             'MarkColrLL':[71,116,71],  #Green MarkerBGR Lower Limit
             'MarkColrUL':[104,150,101],#Green MarkerBGR Upper Limit
             
             'MarkColor':'G'}
            }


