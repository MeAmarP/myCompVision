# -*- coding: utf-8 -*-
"""
File: pyvision.py
Description: pyvision class-implementation
Version: V2.0
Created on Thu Dec 27 14:57:11 2018
@author: apotdar

Robo State Machine Description:
    0: FND
    1: PCK
    2: PAT
    3: DRP
    4: INFO

ToDo:
    - Add Mark and Object Calc Dist functions

"""

#import multiprocessing as mp


from sklearn.neural_network import MLPClassifier
from joblib import load
import numpy as np
import cv2
import roboparam
import time
import logging

#logger = logging.getLogger(__name__)
#cons_handler = logging.StreamHandler()
#cons_handler.setLevel(logging.DEBUG)
#cons_handler.setFormatter('%(asctime)s-%(name)s-%(levelname)s-%(message)s')
#logger.addHandler(cons_handler)

class pyvision():
    ObjPickStat = False
    FailState = False
    FailRoboID = None
    def __init__(self,InputImgPath=None,verbose=False,detector=None):
        self.detector = detector
        self.RoboID = roboparam.MyID
        self.InputImgPath = InputImgPath
        self.brightness = roboparam.VisionPara[self.RoboID]['CameraBright']
        self.myMLP = load('ANN_robo.joblib')
        self.verbose = verbose
#        self.ObjPickStat = False
#        self.setObjPickStatFlag(False)
#        logger.debug('Init Done')


#==============================================================================
    def setObjHSV(self,UpperHSV,LowerHSV):
        self.ObjUpperHSV = UpperHSV
        self.ObjLowerHSV = LowerHSV

    def getObjHSV(self):
        return np.vstack((self.ObjUpperHSV,self.ObjLowerHSV))

    def setMarkHSV(self,UpperHSV,LowerHSV):
        self.MarkUpperHSV = UpperHSV
        self.MarkLowerHSV = LowerHSV

    def getMarkHSV(self):
        return np.vstack((self.MarkUpperHSV,self.MarkLowerHSV)) 
    
#==============================================================================    
    def setObjBGR(self,UpperBGR,LowerBGR):
        self.ObjUpperBGR = UpperBGR
        self.ObjLowerBGR = LowerBGR

    def getObjBGR(self):
        return np.vstack((self.ObjUpperBGR,self.ObjLowerBGR))

    def setMarkBGR(self,UpperBGR,LowerBGR):
        self.MarkUpperBGR = UpperBGR
        self.MarkLowerBGR = LowerBGR

    def getMarkBGR(self):
        return np.vstack((self.MarkUpperBGR,self.MarkLowerBGR))    

#==============================================================================
    def DetectShapeMark(self,InputImg,MarkShape):
        self.ShapeType = MarkShape
        ShapeExtent_Lower = roboparam.MarkerPara[MarkShape]['ExtentLower']
        ShapeExtent_Upper = roboparam.MarkerPara[MarkShape]['ExtentUpper']
        
        InputImg = cv2.cvtColor(InputImg,cv2.COLOR_BGR2GRAY)
        self.ImgHeight,self.ImgWidth = InputImg.shape[:2]
        
        CenterVal = self.ImgWidth / 2
        LowerCenterVal = CenterVal - (CenterVal*0.2) #20Percent Below Center in HoriDir
        UpperCenterVal = CenterVal + (CenterVal*0.2) #20Percent Above Center in HoriDir
        
        MarkStats = dict(isMarkFound=False,MarkLoc=None,MarkDims=[])                 
        
        _,BinImg = cv2.threshold(InputImg,127,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
        (_,contours,hierarchy)=cv2.findContours(BinImg.copy(),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
        
        if contours:
            MarkShapeBBox = np.empty((0,4),int)
            MarkCenters = np.empty((0,2),int)        
            for num,cnt in enumerate(contours):
                area = cv2.contourArea(cnt)
                if area > 10:
                    M = cv2.moments(contours[num])
                    if M["m00"] != 0:
                        cx = int(M["m10"] / M["m00"])
                        cy = int(M["m01"] / M["m00"])                           
                        x,y,w,h = cv2.boundingRect(cnt)
    #                    AllBBox.append([x,y,w,h,num])
                        rectArea = w*h
                        CurrExtent = float(area/rectArea)
                        if ShapeExtent_Lower < CurrExtent < ShapeExtent_Upper:
                            MarkShapeBBox = np.append(MarkShapeBBox,np.array([[x,y,w,h]]),axis=0)
                            MarkCenters = np.append(MarkCenters,np.array([[cx,cy]]),axis=0)                        
            MarkShapeBBox = MarkShapeBBox[np.argsort(MarkShapeBBox[:,0]),:]    
            alignedMarkShape = np.diff(MarkShapeBBox[:,[0,2,3]],axis=0)
            foundMarkShape = np.flatnonzero(((np.abs(alignedMarkShape)) <=11).all(axis=1))
            
            #Move Direction

            while (len(foundMarkShape) > 0):
                cx_Mark,cy_Mark,w_Mark,h_Mark = MarkShapeBBox[foundMarkShape[0],:]
                MarkStats['MarkDims'] = [cx_Mark,cy_Mark,w_Mark,h_Mark]
                MarkStats['isMarkFound'] = True
                if (w_Mark > 70 and h_Mark > 75):
                    MarkStats['isMarkFound']=True
                    MarkStats['MarkLoc'] = 'B'
                    break
                elif(cx_Mark < LowerCenterVal):
                    MarkStats['isMarkFound']=True
                    MarkStats['MarkLoc'] = 'L'
                    break
                elif(cx_Mark > UpperCenterVal):
                    MarkStats['isMarkFound']=True
                    MarkStats['MarkLoc'] = 'R'                
                    break
                elif(LowerCenterVal < cx_Mark < UpperCenterVal):
                    MarkStats['isMarkFound'] =True
                    MarkStats['MarkLoc'] = 'C'
                    break            
            else:
                MarkStats['isMarkFound'] = False
        else:
            MarkShapeBBox = None
            foundMarkShape=None
        return MarkShapeBBox,foundMarkShape,MarkStats
        
    
        
        
    def DetectColorMark(self,InputImg):
        if self.detector == 'BGR':
            DetectVal = self.getMarkBGR()
            #For BGR Image space conversion isn't required
        if self.detector == 'HSV':
            DetectVal = self.getMarkHSV()
            InputImg = cv2.cvtColor(InputImg,cv2.COLOR_BGR2HSV) 
        else:
            raise Exception("Marker Detector value isn\'t initialised to \'BGR\' or \'HSV\' ")
#            logger.error("Marker Detector value isn\'t initialised")
        self.ImgHeight,self.ImgWidth = InputImg.shape[:2]
        #print(InputImg.shape[:2])
        #Mark Detection ROIs
        CenterVal = self.ImgWidth / 2
        LowerCenterVal = CenterVal - (CenterVal*0.3) #20Percent Below Center in HoriDir
        UpperCenterVal = CenterVal + (CenterVal*0.3) #20Percent Above Center in HoriDir
        
        #Create Mask
        ColorMask = cv2.inRange(InputImg,DetectVal[1],DetectVal[0])
        # Some Morph Opertations
        Kernel = np.ones((5,5),"uint8")
        ColorMask = cv2.dilate(ColorMask,Kernel)
        # Find Contours
        #print("Find Markers In Image")
        MarkStats = dict(isMarkFound=False,MarkLoc=None,MarkDims=[])
        (_,contours,hierarchy)=cv2.findContours(ColorMask,
                                                cv2.RETR_TREE,
                                                cv2.CHAIN_APPROX_SIMPLE)
        if len(contours) ==  0:
            #pass
            MarkStats['isMarkFound'] = False
#            logger.warning('Unable to find Marker in Image Data')
            #MarkStats['MarkLoc'] = None
        else:
            for marks in contours:
                MarkArea = cv2.contourArea(marks)
                if(MarkArea > 300):
                    x,y,w,h = cv2.boundingRect(marks)
                    RectDims=[x,y,w,h]
                    if len(RectDims)>0:
                        MarkStats['MarkDims']=RectDims
                        if (w > 190 and h > 220):
                            MarkStats['isMarkFound']=True
                            MarkStats['MarkLoc'] = 'B'
                        elif(x+w/2 < LowerCenterVal):
                            MarkStats['isMarkFound']=True
                            MarkStats['MarkLoc'] = 'L'
                            break
                        elif(x+w/2 > UpperCenterVal):
                            MarkStats['isMarkFound']=True
                            MarkStats['MarkLoc'] = 'R'
                            break
                        elif(x+w/2 > LowerCenterVal and x+w/2 < UpperCenterVal):
                            MarkStats['isMarkFound'] =True
                            MarkStats['MarkLoc'] = 'C'
                            break
                else:
                    #Mark Not Found
                    MarkStats['isMarkFound'] = False
#                    logger.warning('Unable to find Marker in Image Data')
        #print(MarkStats)
        return MarkStats


    def DetectObject(self,InputImg):
        if self.detector == 'BGR':
            DetectVal = self.getObjBGR()
            #For BGR Image space conversion isn't required
        if self.detector == 'HSV':
            DetectVal = self.getObjHSV()        
            InputImg = cv2.cvtColor(InputImg,cv2.COLOR_BGR2HSV)
        else:
            raise Exception("Object Detector value isn\'t initialised to \'BGR\' or \'HSV\' ")            
#            logger.error("Object Detector value isn\'t initialised")
        #Object Detection ROIs
        CenterVal = self.ImgWidth / 2
        LowerCenterVal = CenterVal - (CenterVal*0.2) #20Percent Below Center in HoriDir
        UpperCenterVal = CenterVal + (CenterVal*0.2) #20Percent Above Center in HoriDir
        
        #Create Massk
        ColorMask = cv2.inRange(InputImg,DetectVal[1],DetectVal[0])
        # Some Morph Opertations
        Kernel = np.ones((5,5),"uint8")
        ColorMask = cv2.dilate(ColorMask,Kernel)
        # Find Contours
        ObjStats = dict(isObjFound=False,ObjLoc=None,ObjDims=[])
        (_,contours,hierarchy)=cv2.findContours(ColorMask,
                                                cv2.RETR_TREE,
                                                cv2.CHAIN_APPROX_SIMPLE)
        if len(contours) ==  0:
            #pass
            ObjStats['isObjFound'] = False            
            #MarkStats['MarkLoc'] = None
        else:
            for obj in contours:
                ObjArea = cv2.contourArea(obj)
                if (ObjArea > 300):
                    x,y,w,h = cv2.boundingRect(obj)
                    RectDims=[x,y,w,h]
                    ObjThresh = abs(w-h)
                    if len(RectDims)>0:
                        if ObjThresh <= 13:
                            ObjStats['ObjDims']=RectDims
                            if(x+w/2 < LowerCenterVal):
                                ObjStats['isObjFound']=True
                                ObjStats['ObjLoc'] = 'L'
                                break
                            elif(x+w/2 > UpperCenterVal):
                                ObjStats['isObjFound']=True
                                ObjStats['ObjLoc'] = 'R'
                                break
                            elif(x+w/2 > LowerCenterVal and x+w/2 < UpperCenterVal):
                                ObjStats['isObjFound'] =True
                                ObjStats['ObjLoc'] = 'C'
                                break
                else:
                    #Object Not Found
                    ObjStats['isObjFound'] = False
        #print(ObjStats)
        return ObjStats

    def getAllStats(self):
        if self.verbose == True:
            InputImg = cv2.imread(self.InputImgPath)
        else:
            import pycamera
            camcls = pycamera.initPiCamera()
            InputImg = pycamera.capturePic(camcls,self.brightness)
            #InputImg = cv2.imread('/home/pi/Documents/PHASE2/v2/img/1.jpg')
        _,_,MarkStat = self.DetectShapeMark(InputImg)
        ObjStat = self.DetectObject(InputImg)
        AllStat = {**MarkStat,**ObjStat}
        #Queue.put(AllStat)
        return AllStat

#===============================================================================
    def MarkToCamDist(self,MarkDims):
        #Define Related Constantss
        CamFocLen =  68             #mm
        MarkRealWidth = 700         #mm
        MarkPxlWidth = MarkDims[2]  #Pixels
        distance = (MarkRealWidth * CamFocLen) / (MarkPxlWidth)
        return round(distance)

    def ObjToCamDist(self,ObjDims):
        #Define Related Constants
        CamFocLen =  68             #mm
        ObjRealWidth = 400          #mm
        ObjPxlWidth = ObjDims[2]    #Pixels
        distance = (ObjRealWidth * CamFocLen) / (ObjPxlWidth)
        return round(distance)

#===============================================================================
    def predictRoboState(self,Queue):
        AllStats = self.getAllStats()
        #print("\n\nCurrent Data=",AllStats)
        ObjFoundStat = AllStats['isObjFound']
        MarkFoundStat = AllStats['isMarkFound']
        PickStat = self.ObjPickStat
        myMLP = self.myMLP
        resultState = myMLP.predict([[PickStat, MarkFoundStat, ObjFoundStat]])
        #print("Predicated State = ", resultState)
        AllStats['MachineState'] = resultState
        print("\n\nFinal Data =", AllStats)
        Queue.put(AllStats)
        time.sleep(0.5)


    def run_pyvision(self,Queue):
        while True:
            self.predictRoboState(Queue)
            time.sleep(0.2)


#==============================================================================
def main():
    from threading import Thread
    from queue import Queue
    import roboparam


    RoboID = 'R111'
    q_out = Queue()

    mivis = pyvision(InputImgPath='img/Green1.jpg')
    mivis.setMarkHSV(roboparam.VisionPara[RoboID]['MarkColrUL'],
                     roboparam.VisionPara[RoboID]['MarkColrLL'])

    mivis.setObjHSV(roboparam.VisionPara[RoboID]['ObjColrUL'],
                    roboparam.VisionPara[RoboID]['ObjColrLL'])

    mivis.predictRoboState(q_out)


#    visionThread = Thread(target=mivis.predictRoboState, args=(q_out,))
#    visionThread.start()


    return

if (__name__ == "__main__"):
    main()




