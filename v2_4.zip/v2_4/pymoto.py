#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
---Module pymoto---
Python module for robot DC motor control appilcation
@author: apotdar

Robo State Machine Description:
    0: FND
    1: PCK
    2: PAT
    3: DRP
    4: INFO
"""
from pyvision import pyvision
import RPi.GPIO as GPIO
import time
#import pycomm
import roboparam

class pymoto(pyvision):
    
    def __init__(self,verbose=None):
        #self.AllStats=None
        self.verbose = verbose
#        self.pyvision = pyvision()

        self.RoboID = roboparam.MyID
        self.RoboZone = roboparam.VisionPara[self.RoboID]['MarkColor']

        self.Turn180DutyCycle = roboparam.MotionPara[self.RoboID]['Turn180DutyCycle']
        self.Turn180Time = roboparam.MotionPara[self.RoboID]['Turn180Time']
        self.Turn10DutyCycle = roboparam.MotionPara[self.RoboID]['Turn10DutyCycle']
        self.Turn10Time = roboparam.MotionPara[self.RoboID]['Turn10Time']
        self.FwdDutyCycle = roboparam.MotionPara[self.RoboID]['FwdDutyCycle']
        self.FwdTime = roboparam.MotionPara[self.RoboID]['FwdTime']
        self.PickDist = roboparam.MotionPara[self.RoboID]['PickDist']

        self.MotorLeft_C_Pin = 36    #LFTM_C = 36
        self.MotorLeft_D_Pin = 38    #LFTM_D = 38
        self.MotorLeft_EN_Pin = 32   #LFTM_E = 32
        self.MotorRight_C_Pin = 40   #RGTM_C = 40
        self.MotorRight_D_Pin = 37   #RGTM_D = 37
        self.MotorRight_EN_Pin = 33   #RGTM_E = 33
        self.ElecMag_Pin = 11    #ELMAG = 11
        
    def setObjPickStatFlag(self,FlagVal):
        pyvision.ObjPickStat = FlagVal


    def getObjPickStatFlag(self):
        return pyvision.ObjPickStat


        GPIO.setmode(GPIO.BOARD)
        GPIO.setwarnings(False)

        GPIO.setup(self.MotorLeft_C_Pin, GPIO.OUT, initial = 0)
        GPIO.setup(self.MotorLeft_D_Pin, GPIO.OUT, initial = 0)
        GPIO.setup(self.MotorRight_C_Pin, GPIO.OUT, initial = 0)
        GPIO.setup(self.MotorRight_D_Pin, GPIO.OUT, initial = 0)
        GPIO.setup(self.ElecMag_Pin, GPIO.OUT, initial = 0)

        GPIO.setup(self.MotorLeft_EN_Pin, GPIO.OUT) # This pin to be configured as PWM
        self.MotorLeft_PWM = GPIO.PWM(self.MotorLeft_EN_Pin, 1000) # Create PWM instance with freq as 10 KHz


        GPIO.setup(self.MotorRight_EN_Pin, GPIO.OUT)
        self.MotorRight_PWM = GPIO.PWM(self.MotorRight_EN_Pin, 1000) # Create PWM instance with freq as 10 KHz

        self.AllRoboStates = {0:self.stateFND,
                           1:self.statePCK,
                           2:self.statePAT,
                           3:self.stateDRP,
                           4:self.stateINFO}

    def forward(self,DutyCycle, MovTime):
        if not self.verbose:
            GPIO.output(self.MotorLeft_C_Pin, 1)
            GPIO.output(self.MotorLeft_D_Pin, 0)
            GPIO.output(self.MotorRight_C_Pin, 1)
            GPIO.output(self.MotorRight_D_Pin, 0)
            self.MotorLeft_PWM.start(DutyCycle) #90
            self.MotorRight_PWM.start(DutyCycle) #90
            time.sleep(MovTime)
            GPIO.output(self.MotorLeft_C_Pin, 0)
            GPIO.output(self.MotorLeft_D_Pin, 1)
            GPIO.output(self.MotorRight_C_Pin, 0)
            GPIO.output(self.MotorRight_D_Pin, 1)
        else:
            print("Moving FWD with Duty,Time", DutyCycle, MovTime)

    def reverse(self,DutyCycle, MovTime):
        if not self.verbose:
            print('reverse')
            GPIO.output(self.MotorLeft_C_Pin, 0)
            GPIO.output(self.MotorLeft_D_Pin, 1)
            GPIO.output(self.MotorRight_C_Pin, 0)
            GPIO.output(self.MotorRight_D_Pin, 1)
            self.MotorLeft_PWM.start(DutyCycle)
            self.MotorRight_PWM.start(DutyCycle)
            time.sleep(MovTime)
            GPIO.output(self.MotorLeft_C_Pin, 1)
            GPIO.output(self.MotorLeft_D_Pin, 0)
            GPIO.output(self.MotorRight_C_Pin, 1)
            GPIO.output(self.MotorRight_D_Pin, 0)
        else:
            print("Moving REV with Duty,Time", DutyCycle, MovTime)


    def turnleft(self,DutyCycle, MovTime):
        if not self.verbose:
            GPIO.output(self.MotorLeft_C_Pin, 0)
            GPIO.output(self.MotorLeft_D_Pin, 1)
            GPIO.output(self.MotorRight_C_Pin, 1)
            GPIO.output(self.MotorRight_D_Pin, 0)
            self.MotorLeft_PWM.start(DutyCycle)
            self.MotorRight_PWM.start(DutyCycle)
            time.sleep(MovTime)
        else:
            print("Turning LEFT with Duty,Time", DutyCycle, MovTime)

    def turnright(self,DutyCycle, MovTime):
        if not self.verbose:
            GPIO.output(self.MotorLeft_C_Pin, 1)
            GPIO.output(self.MotorLeft_D_Pin, 0)
            GPIO.output(self.MotorRight_C_Pin, 0)
            GPIO.output(self.MotorRight_D_Pin, 1)
            self.MotorLeft_PWM.start(DutyCycle)
            self.MotorRight_PWM.start(DutyCycle)
            time.sleep(MovTime)
        else:
            print("Turning RIGHT with Duty,Time", DutyCycle, MovTime)

    def stop(self):
        if not self.verbose:
            self.MotorLeft_PWM.stop()
            self.MotorRight_PWM.stop()
            GPIO.output(self.MotorLeft_C_Pin, 0)
            GPIO.output(self.MotorLeft_D_Pin, 0)
            GPIO.output(self.MotorRight_C_Pin, 0)
            GPIO.output(self.MotorRight_D_Pin, 0)
        else:
            print("Stopped")


    def energize(self):
        if not self.verbose:
            GPIO.output(self.ElecMag_Pin, 1)
        else:
            print("\nEnergizng ElecMag")

    def deenergize(self):
        if not self.verbose:
            GPIO.output(self.ElecMag_Pin, 0)
        else:
            print("\nDeEnergizng ElecMag")


    def GotoRoboState(self,Queue):
        if not self.verbose:
            self.AllStats = Queue.get()
            print(self.AllStats)
            self.MachineState = self.AllStats['MachineState']
            self.MarkLoc = self.AllStats['MarkLoc']
            self.ObjLoc =self.AllStats['ObjLoc']
            self.MarkDims = self.AllStats['MarkDims']
            self.ObjDims = self.AllStats['ObjDims']
            self.AllRoboStates[self.MachineState[0]]()
        else:
            self.AllStats = Queue.get()
            print("\n\nData at pymoto",self.AllStats)


    def run_pymoto(self,Queue):
        while True:

            self.GotoRoboState(Queue)
            time.sleep(0.2)

#===============================================================================
# State Machines
    def statePAT(self):
        print('Patroling...')
        #pycomm.setRoboZone(self.RoboID, self.RoboZone)
        #pycomm.setRoboAct(self.RoboID,'PAT')

        MarkLoc = self.MarkLoc
        #MarkColor = MarkStat.get('MarkerColor')
        if(MarkLoc == 'L'):
            print('Move L')
            self.turnleft(self.Turn10DutyCycle,self.Turn10Time)
            self.stop()
        elif(MarkLoc == 'R'):
            self.turnright(self.Turn10DutyCycle,self.Turn10Time)
            self.stop()
        elif(MarkLoc == 'C'):
            MarkDist = pyvision.MarkToCamDist(self.MarkDims)
        #print(MarkDist)
            if (MarkDist>=1000):
                self.forward(self.FwdDutyCycle,3*self.FwdTime)
                self.stop()
            else:
                self.forward(self.FwdDutyCycle,self.FwdTime)
                self.stop()
        elif(MarkLoc == 'B'):
            self.turnright(self.Turn180DutyCycle,self.Turn180Time)
            self.stop()
            


    def statePCK(self):
        print('Picking Obj...')
        #MyZone = MarkStat.get('MarkColor')
        #pycomm.setRoboZone(self.RoboID, self.RoboZone)
        #pycomm.setRoboAct(self.RoboIDMyID,'PCK')
        ObjLoc = self.ObjLoc
        if(ObjLoc == 'L'):
            self.turnleft(self.Turn10DutyCycle,self.Turn10Time)
            self.stop()
            #isPickObj = True
        elif(ObjLoc=='R'):
            self.turnright(self.Turn10DutyCycle,self.Turn10Time)
            self.stop()
            #isPickObj = True
        elif(ObjLoc=='C'):
            ObjDist = pyvision.ObjToCamDist(self.ObjDims)
            #pycomm.setRoboObjDist(self.RoboID,ObjDist)
            #print(ObjDist)
            #Decision needs to be taken Only Once... Not Everytime
            #MyActFlag = getActDecision(MyID)
            MyActFlag = True #Testing Purpose Only

            if MyActFlag == True:
                pyvision.setObjPickStatFlag(True)
                self.forward(self.FwdDutyCycle,self.FwdTime)
                self.stop()
                if ObjDist < 0.8*self.PickDist:
                    print('Energized')
                    self.energize()
                    self.forward(self.FwdDutyCycle,self.FwdTime)
                    pyvision.setObjPickStatFlag(True)
                    #pycomm.setRoboObjDist(self.RoboID,0)
            elif MyActFlag == False:
                pyvision.setObjPickStatFlag(False)
                print('Picking False')
                #pycomm.setRoboObjDist(self.RoboID,0)
                #GetOut from the pick obj state and go in patroling
        #print("Picking Object at ",self.MarkLoc, self.ObjLoc)

    def stateDRP(self):
        print('Dropping Object...')
        #pycomm.setRoboObjDist(self.RoboID,0)
        #pycomm.setRoboZone(self.RoboID, self.RoboZone)
        #pycomm.setRoboAct(self.RoboID,'DRP')

        MarkLoc = self.MarkLoc
        if (MarkLoc == 'L'):
            self.turnleft(self.Turn10DutyCycle,self.Turn10Time)
            self.stop()
        elif(MarkLoc == 'R'):
            self.turnright(self.Turn10DutyCycle,self.Turn10Time)
            self.stop()
        elif(MarkLoc == 'C'):
            #MarkDist = self.pyvision.MarkToCamDist(self.MarkDims)
            #print(MarkDist)
            self.forward(self.FwdDutyCycle,self.FwdTime)
            self.stop()
        elif(MarkLoc == 'B'):
            print('De-Energized')
            self.deenergize()
            pyvision.setObjPickStatFlag(True)
            self.turnright(self.Turn180DutyCycle,self.Turn180Time)
            self.stop()

    def stateFND(self):
        print("Finding Marker at ",self.MarkLoc, self.ObjLoc)
        #pycomm.setRoboZone(self.RoboID, self.RoboZone)
        #pycomm.setRoboObjDist(self.RoboID,0)
        MarkLoc = self.MarkLoc
        if MarkLoc == 'L':
            self.turnleft(50,0.4)
            self.stop()
        elif MarkLoc == 'R':
            self.turnright(50,0.4)
            self.stop()


    def stateINFO(self):
        print("Inform Others for ",self.MarkLoc, self.ObjLoc)
#===============================================================================
def main():
#    from threading import Thread
    from queue import Queue
    from pyvision import pyvision
    
    vis = pyvision()

    q_in = Queue()
    mimoto = pymoto(vis,verbose=True)

    ImgOutput = dict(MachineState=[2],MarkLoc='L',ObjLoc='C',
                     MarkDims=[101, 77, 166, 29],
                     ObjDims=[253, 39, 60, 60])
    q_in.put(ImgOutput)

    mimoto.GotoRoboState(q_in)
#    motionThread = Thread(target=mimoto.GotoRoboState, args=(q_in,))
#    motionThread.start()


if (__name__ == "__main__"):
    main()





