# -*- coding: utf-8 -*-
"""
Created on Fri Feb  8 14:42:36 2019

@author: apotdar
"""

import cv2
import numpy as np
import time


def DetectShapeMark(InputImg,MarkShape):
        ShapeType = MarkShape
        ShapeExtent_Lower = Marker[ShapeType]['ExtentLower']
        ShapeExtent_Upper = Marker[ShapeType]['ExtentUpper']
        
        InputImg = cv2.cvtColor(InputImg,cv2.COLOR_BGR2GRAY)
        ImgHeight,ImgWidth = InputImg.shape[:2]
        
        CenterVal = ImgWidth / 2
        LowerCenterVal = CenterVal - (CenterVal*0.2) #20Percent Below Center in HoriDir
        UpperCenterVal = CenterVal + (CenterVal*0.2) #20Percent Above Center in HoriDir
        
        MarkStats = dict(isMarkFound=False,MarkLoc=None,MarkDims=[])                 
        
        _,BinImg = cv2.threshold(InputImg,127,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
        (_,contours,hierarchy)=cv2.findContours(BinImg.copy(),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
        
        if contours:
            MarkShapeBBox = np.empty((0,4),int)
            MarkCenters = np.empty((0,2),int)        
            for num,cnt in enumerate(contours):
                area = cv2.contourArea(cnt)
                if area > 10:
                    M = cv2.moments(contours[num])
                    if M["m00"] != 0:
                        cx = int(M["m10"] / M["m00"])
                        cy = int(M["m01"] / M["m00"])                           
                        x,y,w,h = cv2.boundingRect(cnt)
    #                    AllBBox.append([x,y,w,h,num])
                        rectArea = w*h
                        CurrExtent = float(area/rectArea)
                        if ShapeExtent_Lower < CurrExtent < ShapeExtent_Upper:
                            MarkShapeBBox = np.append(MarkShapeBBox,np.array([[x,y,w,h]]),axis=0)
                            MarkCenters = np.append(MarkCenters,np.array([[cx,cy]]),axis=0)                        
            MarkShapeBBox = MarkShapeBBox[np.argsort(MarkShapeBBox[:,0]),:]    
            alignedMarkShape = np.diff(MarkShapeBBox[:,[0,2,3]],axis=0)
            foundMarkShape = np.flatnonzero(((np.abs(alignedMarkShape)) <=11).all(axis=1))
            
            #Move Direction
            if MarkShapeBBox.all():
                cx_Mark = MarkShapeBBox[foundMarkShape[0],0]
                MarkStats['MarkDims'] = MarkShapeBBox[foundMarkShape[0],:]
                while (len(foundMarkShape) > 0):
                    MarkStats['isMarkFound'] = True
                    if(cx_Mark < LowerCenterVal):
                        MarkStats['isMarkFound']=True
                        MarkStats['MarkLoc'] = 'L'
                        break
                    elif(cx_Mark > UpperCenterVal):
                        MarkStats['isMarkFound']=True
                        MarkStats['MarkLoc'] = 'R'                
                        break
                    elif(LowerCenterVal < cx_Mark < UpperCenterVal):
                        MarkStats['isMarkFound'] =True
                        MarkStats['MarkLoc'] = 'C'
                        break            
                else:
                    MarkStats['isMarkFound'] = False
        else:
            MarkShapeBBox = None
            foundMarkShape=None
        return MarkShapeBBox,foundMarkShape,MarkStats
    
if (__name__ == "__main__"):
    Marker ={
        'Circle':{'ExtentUpper':0.85,'ExtentLower':0.65},
        'Star':{'ExtentUpper':0.39,'ExtentLower':0.2},
        'TriAng':{'ExtentUpper':0.65,'ExtentLower':0.39}            
        }
        
    ImgPath = "FEB4_pics/NW9.jpg"
    MainImg = cv2.imread(ImgPath)
    start = time.time()
    MarkBBox,foundMarkShape,MarkStat = DetectShapeMark(MainImg,MarkShape='Circle')
    #Act_foundMark = foundMarkShape - 1
    print('\nExecution Time= ', time.time() - start)
    
    print(MarkStat)
    tpl_MarkVal = tuple(map(tuple,MarkBBox[foundMarkShape[:],:2]))
    for tplVal in tpl_MarkVal:
        cv2.putText(MainImg,
                    '.',
                    tplVal,
                    cv2.FONT_HERSHEY_SIMPLEX,2,
                    (0,255,0),2)
    cv2.imshow('Result', MainImg)
    
    