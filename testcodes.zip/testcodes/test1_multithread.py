# -*- coding: utf-8 -*-
"""
Created on Mon Dec 17 14:09:09 2018

@author: apotdar
"""

import time
import threading

def myFunc(numVal):
    print('I Am ',numVal)
    return

if __name__ == '__main__':
    start = time.time()
    #time.sleep(0.5)
    for i in range(3):
        #myFunc(i+1)
        t = threading.Thread(target=myFunc, args=(i,))
        t.start()        
    print('Exec Time = ', time.time() - start)        
        