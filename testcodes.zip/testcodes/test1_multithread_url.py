# -*- coding: utf-8 -*-
"""
Created on Thu Dec 20 15:00:58 2018

@author: apotdar
"""

import urllib3
from multiprocessing.dummy import Pool as ThreadPool 

urls = [
  'http://www.python.org', 
  'http://www.python.org/about/',
  'http://www.python.org/doc/',
  'http://www.python.org/download/',
  'http://www.python.org/getit/',
  'http://www.python.org/community/',
  'http://docs.python.org/devguide/',
  'http://www.python.org/community/awards/'
  ]

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def URLRequest(urls):
    http = urllib3.PoolManager()    
    return http.request('GET',urls)


num = [1,2,3,4]
def sqr(num):
    return num*num

# Make the Pool of workers
pool1 = ThreadPool(12)
pool2 = ThreadPool(4) 
# Open the urls in their own threads
# and return the results
results1 = pool1.map(URLRequest, urls)
results2 = pool2.map(sqr,num)
#close the pool and wait for the work to finish 
pool1.close()
pool2.close()

pool1.join()
pool2.join()

