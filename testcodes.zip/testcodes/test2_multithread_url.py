# -*- coding: utf-8 -*-
"""
Created on Thu Dec 20 16:00:44 2018

@author: apotdar
"""
import urllib3

urls = [
  'http://www.python.org', 
  'http://www.python.org/about/',
  'http://www.python.org/doc/',
  'http://www.python.org/download/',
  'http://www.python.org/getit/',
  'http://www.python.org/community/',
  'http://docs.python.org/devguide/',
  'http://www.python.org/community/awards/'
  ]

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

AllResult = []
http = urllib3.PoolManager()    

for url in urls:
    result = http.request('GET',url)
    AllResult.append(result)
    
    
    
