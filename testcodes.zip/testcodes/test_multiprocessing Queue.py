# -*- coding: utf-8 -*-
"""
# How to use multiprocessing.Queue as a FIFO queue:
Created on Fri Dec 21 12:46:32 2018

@author: apotdar
"""

from multiprocessing.dummy import Pool as ThreadPool
import multiprocessing as mp
#import time



def pyvision(AllQue,Msg):
    ObjStat = dict(isObjFound=True,ObjLoc='R')
    MarkStat = dict(isMarkFound=True,MarkLoc='L')
    ObjStat.update(MarkStat)
    print(Msg)
    AllQue.put(ObjStat)
    

def pymotocon(AllQue):
    AllStat = AllQue.get()
    result=[]
    ObjLoc =  AllStat['ObjLoc']
    result.append(ObjLoc)
    ObjFound = AllStat['isObjFound']    
    result.append(ObjFound) 
    print("Results = [ObjLoc, isObjFound]: ",result)
    
if __name__ == '__main__':
    manager = mp.Manager()
    AllQue = manager.Queue()
    Msg = "I AM Groot"    
    #pyvision(AllQue)
    visionPool = ThreadPool(4) #NotUsed
    motoPool = ThreadPool(4)
        
    visionPool.apply_async(pyvision,(AllQue,Msg))    
    motoPool.apply_async(pymotocon,(AllQue,))
    
    visionPool.close()
    motoPool.close()
    
    visionPool.join()
    motoPool.join()
    #pymotocon(AllQue)