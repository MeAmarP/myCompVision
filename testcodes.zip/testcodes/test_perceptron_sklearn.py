# -*- coding: utf-8 -*-
"""
Perceptron learning rule
Created on Wed Dec 19 11:58:22 2018

@author: apotdar
"""

import numpy as np
from sklearn.datasets import load_iris
from 