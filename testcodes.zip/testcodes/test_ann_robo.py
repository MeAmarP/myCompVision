# -*- coding: utf-8 -*-
"""
Deep Neural Network for myRobo
Created on Wed Dec 19 15:17:50 2018

@author: apotdar
"""

import numpy as np
from sklearn.neural_network import MLPClassifier

#Input Data
#--Pick Status--Mark Found--Object Found
X = np.array([
        0,0,0,
        0,0,1,
        0,1,0,
        0,1,1,
        1,0,0,
        1,0,1,
        1,1,0,
        1,1,1]).reshape(8,3)

#Output(MyState)
y = np.array([
        0,  #FND
        1,  #PCK
        2,  #PAT
        1,  #PCK
        0,  #FND
        4,  #INFO
        3,  #DRP
        4   #INFO
        ]).reshape(8,1)


mlp = MLPClassifier(activation='relu',hidden_layer_sizes = (14,),max_iter=10000)
mlp.fit(X,y.ravel())

predictions = mlp.predict(X)

print("Desired Output = ", y.ravel())
print("Prediction = ", predictions)
print("MLP Score = ", mlp.score(X,y.ravel()))