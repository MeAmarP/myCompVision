# -*- coding: utf-8 -*-
"""
Created on Wed Dec  5 12:10:27 2018

@author: apotdar
"""

#myActFlag = False
ObjLoc = 'C'

def goPickObj(ObjLoc):
    ActFlag = False 
    if (ObjLoc == 'C' and ActFlag == False):
        print('Get Act Decsion')
        ActFlag = True
    elif (ObjLoc == 'C' and ActFlag == True):
        print('Go Do Act')
        ActFlag = False
    return ActFlag


if __name__ ==  "__main__":
    action = goPickObj(ObjLoc)
    myActFlag = action