# -*- coding: utf-8 -*-
"""

flexible Neural Network with Backpropagation
Created on Tue Dec 18 15:17:14 2018

@author: apotdar
"""

import numpy as np

# X = (hours sleeping, hours studying), y = score on test
actual_X = np.array(([2, 9], [1, 5], [3, 6]), dtype=float)
actual_y = np.array(([92], [86], [89]), dtype=float)

# scale units
X = actual_X/np.amax(actual_X, axis=0) # maximum of X array
y = actual_y/100 # max test score is 100

class NeuralNet(object):
    def __init__(self):
        self.InputSize = 2
        self.OutputSize = 1
        self.HiddenSize = 3
        #weights
        self.W1 = np.random.randn(self.InputSize, self.HiddenSize) # (3x2) weight matrix from input to hidden layer
        self.W2 = np.random.randn(self.HiddenSize, self.OutputSize) # (3x1) weight matrix from hidden to output layer
        
    def forward(self, X):
        #forward propagation through our network
        self.z = np.dot(X, self.W1) # dot product of X (input) and first set of 3x2 weights
        self.z2 = self.sigmoid(self.z) # activation function
        self.z3 = np.dot(self.z2, self.W2) # dot product of hidden layer (z2) and second set of 3x1 weights
        o = self.sigmoid(self.z3) # final activation function
        return o
    
    def sigmoid(self, s):
        # activation function 
        return 1/(1+np.exp(-s))

    def DerivatSigmoid(self, s):
        #derivative of sigmoid
        return s * (1 - s)
    
    def backward(self, X, y, o):
        # backward propgate through the network
        self.o_error = y - o # error in output
        self.o_delta = self.o_error*self.DerivatSigmoid(o) # applying derivative of sigmoid to error
    
        self.z2_error = self.o_delta.dot(self.W2.T) # z2 error: how much our hidden layer weights contributed to output error
        self.z2_delta = self.z2_error*self.DerivatSigmoid(self.z2) # applying derivative of sigmoid to z2 error
    
        self.W1 += X.T.dot(self.z2_delta) # adjusting first set (input --> hidden) weights
        self.W2 += self.z2.T.dot(self.o_delta) # adjusting second set (hidden --> output) weights
        
    def train (self, X, y):
        o = self.forward(X)
        self.backward(X, y, o)
    
myNN = NeuralNet()

for i in range(3000): # trains the NN 1,000 times
    myNN.train(X, y)
    
#print ("Input: \n", actual_X) 
print ("Desired Output: \n", y) 
print ("Predicted Output: \n" , myNN.forward(X) ) 
print ("Loss: \n", np.mean(np.square(y - myNN.forward(X)))) # mean sum squared loss    
    
    
    