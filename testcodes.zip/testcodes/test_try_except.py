# -*- coding: utf-8 -*-
"""
Created on Wed Nov 14 10:42:47 2018

@author: apotdar
"""

#Testing with try-Except and While

import time

while True:
    myCodeFlag = True
    while myCodeFlag:
        print('Run Main Code')    
        time.sleep(0.5)
        myCodeFlag = False
    else:
        myCodeFlag = True
        print('Been here')
        
   
    