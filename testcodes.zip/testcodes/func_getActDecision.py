# -*- coding: utf-8 -*-
"""
Created on Tue Dec  4 14:04:31 2018

@author: apotdar
"""
import numpy as np
R111Dist = 450
R105Dist = 0
R104Dist = 45

#AllDistDict = {}
#AllDist = np.array([R111Dist,R105Dist,R104Dist])
#print(AllDist.min())
#print(np.nanargmin(AllDist))

#AllDistDict = {'R111':R111Dist,
#               'R105':R105Dist,
#               'R104':R104Dist}
#AllDist = AllDistDict.values()

AllDistL = [R111Dist,R105Dist,R104Dist]

i= np.where(AllDistL==np.min(AllDistL[list(np.nonzero(AllDistL))]))
print(i)
