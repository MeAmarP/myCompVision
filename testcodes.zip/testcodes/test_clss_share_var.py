# -*- coding: utf-8 -*-
"""
Created on Wed Feb 13 15:19:42 2019

@author: apotdar
"""

class myvision:
    myFlag = False
    def __init__(self,value):
        self.data = value
    
    def display(self):
        print(self.data)
        print(self.myFlag)
      
class mymoto(myvision):
    def __init__(self,):        
        pass
        
    def setmyFlag(self,FlagVal):
        myvision.myFlag = FlagVal
        
    def getmyFlag(self):
        return myvision.myFlag
    
    
mv = myvision(5)
mv.display()

mo = mymoto()
mo.setmyFlag(True)
mv.display()
#mo.setmyFlag(False)
#mv.display()

flagStat = mo.getmyFlag()
print('\nNewFlag:',flagStat)
        