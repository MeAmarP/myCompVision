# -*- coding: utf-8 -*-
"""
Created on Thu Dec  6 19:50:27 2018

@author: apotdar
"""

def int_to_bytes (input) : # input is int.
    num_bits = input.bit_length()	
    num_bytes = (num_bits + 7) // 8
    if ((num_bits % 8) == 0) : num_bytes += 1

    return input.to_bytes(num_bytes, byteorder='big', signed=True)

def int_from_bytes (input) : # input is bytes.
    return int.from_bytes(input, byteorder='big', signed=True)
                          
if __name__ ==  "__main__":
    myVal = 0
    myByte = int_to_bytes(myVal)
    print(myByte)
    myInt = int_from_bytes(myByte)
    print('MyInt', myInt)
                          