# -*- coding: utf-8 -*-
"""
Simple XOR on predict using Neural Network
Created on Tue Dec 18 17:43:39 2018

@author: apotdar
"""

import numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import classification_report, confusion_matrix

X = np.array(([0, 0], [0, 1], [1, 0], [1, 1]), dtype=float)
y = np.array(([0], [1], [1], [0]), dtype=float)

mlp = MLPClassifier(activation='relu',hidden_layer_sizes = (4,2),max_iter=10000)
mlp.fit(X,y.ravel())

predictions = mlp.predict(X)

print("Desired Output = ", y.ravel())
print("Prediction = ", predictions)
print("MLP Score = ", mlp.score(X,y.ravel()))
#print(confusion_matrix(y.ravel(),predictions))
print(classification_report(y.ravel(),predictions))
