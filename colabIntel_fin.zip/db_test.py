import pycomm as  com

While True:

    sleep(1)
    R105Stat = com.getRoboDB(105,'Robo2State')
    R104Stat = com.getRoboDB(104,'Robo3State')

print(R105Stat)
print(R104Stat)
