import RPi.GPIO as GPIO
import time
import threading


LFTM_C = 36
LFTM_D = 38
LFTM_E = 32
RGTM_C = 40
RGTM_D = 37
RGTM_E = 33

ELMAG = 11

#LED1 = 16 
#LED2 = 18
#LED3 = 22
#LED4 = 29
#LED5 = 31


GPIO.setmode(GPIO.BOARD)
GPIO.setup(LFTM_C, GPIO.OUT, initial = 0)
GPIO.setup(LFTM_D, GPIO.OUT, initial = 0)
GPIO.setup(RGTM_C, GPIO.OUT, initial = 0)
GPIO.setup(RGTM_D, GPIO.OUT, initial = 0)
GPIO.setup(ELMAG, GPIO.OUT, initial = 0)

#GPIO.setup(LED1, GPIO.OUT,initial = 1)
#GPIO.setup(LED2, GPIO.OUT,initial = 1)
#GPIO.setup(LED3, GPIO.OUT,initial = 1)
#GPIO.setup(LED4, GPIO.OUT,initial = 1)
#GPIO.setup(LED5, GPIO.OUT,initial = 1)
#GPIO.setup(BUZZ, GPIO.OUT,initial = 1)

GPIO.setup(LFTM_E, GPIO.OUT) # This pin to be configured as PWM
lftm_pwm = GPIO.PWM(LFTM_E, 1000) # Create PWM instance with freq as 10 KHz


GPIO.setup(RGTM_E, GPIO.OUT)
rgtm_pwm = GPIO.PWM(RGTM_E, 1000) # Create PWM instance with freq as 10 KHz

GPIO.setwarnings(False)

try:

#lftm_pwm.ChangeDutyCycle(pwm_dc)
#rgtm_pwm.ChangeDutyCycle(pwm_dc)
#GPIO.output(LFTM_C, lftm_c_state)
#GPIO.output(LFTM_D, lftm_d_state)
    #lftm_pwm.start(pwm_dc)
    def forward(DutyCycle, MovTime):
     GPIO.output(LFTM_C, 1)
     GPIO.output(LFTM_D, 0)
     GPIO.output(RGTM_C, 1)
     GPIO.output(RGTM_D, 0)
     lftm_pwm.start(DutyCycle) #90
     rgtm_pwm.start(DutyCycle) #90
     time.sleep(MovTime)
     GPIO.output(LFTM_C, 0)
     GPIO.output(LFTM_D, 1)
     GPIO.output(RGTM_C, 0)
     GPIO.output(RGTM_D, 1)

     e = threading.Event()
     e.wait(timeout=0.015)

    def reverse(DutyCycle, MovTime):
     GPIO.output(LFTM_C, 0)
     GPIO.output(LFTM_D, 1)
     GPIO.output(RGTM_C, 0)
     GPIO.output(RGTM_D, 1)
     lftm_pwm.start(DutyCycle)
     rgtm_pwm.start(DutyCycle)
     time.sleep(MovTime)
     GPIO.output(LFTM_C, 1)
     GPIO.output(LFTM_D, 0)
     GPIO.output(RGTM_C, 1)
     GPIO.output(RGTM_D, 0)

     e = threading.Event()
     e.wait(timeout=0.015)

    def turnleft(DutyCycle, MovTime):
     GPIO.output(LFTM_C, 0)
     GPIO.output(LFTM_D, 1)
     GPIO.output(RGTM_C, 1)
     GPIO.output(RGTM_D, 0)
     lftm_pwm.start(DutyCycle)
     rgtm_pwm.start(DutyCycle)
     time.sleep(MovTime)
     #GPIO.cleanup()

    def turnright(DutyCycle, MovTime):
     GPIO.output(LFTM_C, 1)
     GPIO.output(LFTM_D, 0)
     GPIO.output(RGTM_C, 0)
     GPIO.output(RGTM_D, 1)
     lftm_pwm.start(DutyCycle)
     rgtm_pwm.start(DutyCycle)
     time.sleep(MovTime)
     #GPIO.cleanup()

    def stop():
     lftm_pwm.stop()
     rgtm_pwm.stop()
     GPIO.output(LFTM_C, 0)
     GPIO.output(LFTM_D, 0)
     GPIO.output(RGTM_C, 0)
     GPIO.output(RGTM_D, 0)

    def energize():
     GPIO.output(ELMAG, 1)

    def deenergize():
     GPIO.output(ELMAG, 0)

#    while True:
   #  forward()
     #sleep(3)
     #stop()
     #reverse()
     #sleep(3)
     #stop()

except KeyboardInterrupt:
    stop()
    GPIO.cleanup()

