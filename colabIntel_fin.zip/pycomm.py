# -*- coding: utf-8 -*-
"""
Python Redis Communication module
Created on Tue Nov 27 17:50:37 2018

@author: apotdar
"""
import redis

RoboDB = redis.Redis(
        host='192.168.1.106',
        port=6379,
        password='')


def setRoboObjDist(RoboID,RoboObjDist):
    strID = str(RoboID)
    strDist = strID + 'Dist'
    RoboDB.set(strDist,RoboObjDist)
    return

#PATROLLING = 'PAT', PICKING = 'PCK', DROPPING = 'DRP', FINDING = 'FND'
def setRoboAct(RoboID,RoboAct):
    strID = str(RoboID)
    strAct = strID + 'Act'
    RoboDB.set(strAct,RoboAct)
    return

def setRoboZone(RoboID,RoboZone):
    strID = str(RoboID)
    strZone = strID + 'Zone'
    RoboDB.set(strZone,RoboZone)
    return


def getRoboDB(RoboID, InputKey):
    strID = str(RoboID)
    strInKey = strID+InputKey
    #print(strInKey)
    OutValue = RoboDB.get(strInKey)      
    return OutValue

def getRoboState(InKey):
    state = RoboDB.get(InKey)
    return str(state)


if __name__ == 'main':
    print('Am Here')
    setRoboZone(105, 'G')
    setRoboObjDist(105,  450)
    setRoboAct(105,'PAT')
    #myID = getRoboDB('RoboIDNum')
    myZone = getRoboDB(105,'Zone')
    myObjDist = getRoboDB(105,'Dist')
    myAct = getRoboDB(105,'Act')
    print(myAct,myZone,myObjDist)
    


