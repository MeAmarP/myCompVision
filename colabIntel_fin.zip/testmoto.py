import RPi.GPIO as io
import time
io.setmode(io.BOARD)

io.setup(11,io.OUT,initial=0)
io.setup(13,io.OUT,initial=0)
io.setup(15,io.OUT,initial=0)
io.setup(16,io.OUT,initial=0)

io.setup(12,io.OUT,initial=0)
io.setup(32,io.OUT,initial=0)

io.output(11,True)
io.output(13,False)
io.output(15,True)
io.output(16,False)


while True:
	io.output(12,True)
	io.output(32,False)
	time.sleep(10)
	io.output(12,False)
	io.output(32,True)
	time.sleep(10)



