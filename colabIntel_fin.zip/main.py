import pycamera
import newmoto
import pyvision
import cv2
import time
import math
import pycomm

#Init Robo Camera and Motor Control Vars
MyID = 'R111'
R111CameraBrightness = 65
R105CameraBrightness = 65
R104CameraBrightness = 60                   #Green=65,Orange=65,Blue=60

Turn180DutyCycle = 90
Turn180Time = 2.7                           # =1.70 On Full-Charge, else use 2
Turn10DutyCycle = 50
Turn10Time = 0.30                           # =0.25 on Full-Charge, else use 0.3
FwdDutyCycle = 100
FwdTime = 1.5                                 # =0.70 On Full-Charge, else use 1
PickDist = 300

#Init Environment Vars
ImgSize = [640,480]                         # 640x480 resolution
R111ObjColLL = [0,50,50]                    # Red Object Lower Limit
R111ObjColUL = [10,255,255]                 # Red Object Upper Limit
R111MarkCol = 'G'
R111MarkColLL = [60,80,80]                # Green Marker Lower Limit
R111MarkColUL = [70,200,200]                # Green Marker Upper Limit

R105ObjColLL = [155,10,10]                  # Pink Object Lower Limit... Check
R105ObjColUL = [220,255,255]                # Pink Object Upper Limit... Check
R105MarkCol = 'O'
R105MarkColLL = [2,80,80]                 # Orange Marker Lower Limit
R105MarkColUL = [40,240,255]                # Orange Marker Upper Limit

R104ObjColLL = [35,150,150]                 # Fluorescent Object Lower Limit
R104ObjColUL = [55,255,255]                 # Fluorescent Object Upper Limit
R104MarkCol = 'B'
R104MarkColLL = [90,90,70]                  # Blue Marker Lower Limit
R104MarkColUL = [110,240,240]               # Blue Marker Upper Limit

MyObjPickedStatus = False
AnyObjPickedStatus = False
MyMarkFlag = True
isPickingObj = True
pycomm.setRoboObjDist(MyID,0)

def statePatroling3(MyID,MarkStat,MyMarkFlag,bright):
    print('Patroling...')
    MyZone = MarkStat.get('MarkColor')
    pycomm.setRoboZone(MyID, MyZone)
    pycomm.setRoboAct(MyID,'PAT')

    MarkLoc = MarkStat.get('MarkLoc')
    #MarkColor = MarkStat.get('MarkerColor')
    if(MarkLoc == 'L'):
        newmoto.turnleft(Turn10DutyCycle,Turn10Time)
        newmoto.stop()
    elif(MarkLoc == 'R'):
        newmoto.turnright(Turn10DutyCycle,Turn10Time)
        newmoto.stop()
    elif(MarkLoc == 'C'):
        MarkDims = MarkStat.get('MarkDims')
        MarkDist = pyvision.MarkToCamDist(MarkDims)
        #print(MarkDist)
        if (MarkDist>=10000):
           newmoto.forward(FwdDutyCycle,7*FwdTime)
           newmoto.stop()
        else:
           newmoto.forward(FwdDutyCycle,FwdTime)
           newmoto.stop()
    elif(MarkLoc == 'B'):
        newmoto.turnright(Turn180DutyCycle,Turn180Time)
        newmoto.stop()
        #FailState,FailedRoboID = checkRoboStates()            # Comment below 2 lines, if this is used
        FailState = 0                                         # For Offline Testing Purpose
        FailedRoboID = None                                   # For Offline Testing Purpose
        if FailState == 0:
            MyMarkFlag = True
        if FailState > 0:
            newmoto.turnleft(Turn180DutyCycle,Turn180Time/2)
            newmoto.stop()
            newmoto.forward(FwdDutyCycle,5)  # FwdTime
            newmoto.stop()
            newmoto.turnright(Turn180DutyCycle,Turn180Time/2)
            newmoto.stop()
            MyMarkFlag = not(MyMarkFlag)
    return MyMarkFlag

def statePickObj(MyID,MarkStat,ObjStat,PickStatus):
    print('Picking Obj...')
    MyZone = MarkStat.get('MarkColor')
    pycomm.setRoboZone(MyID, MyZone)
    pycomm.setRoboAct(MyID,'PCK')

    ObjLoc = ObjStat.get('ObjLoc')
    if(ObjLoc == 'L'):
        newmoto.turnleft(Turn10DutyCycle,Turn10Time)
        newmoto.stop()
        isPickObj = True
    elif(ObjLoc=='R'):
        newmoto.turnright(Turn10DutyCycle,Turn10Time)
        newmoto.stop()
        isPickObj = True
    elif(ObjLoc=='C'):
        ObjDims = ObjStat.get('ObjDims')
        ObjDist = pyvision.ObjToCamDist(ObjDims)
        pycomm.setRoboObjDist(MyID,ObjDist)
        #print(ObjDist)
        #Decision needs to be taken Only Once... Not Everytime        
        #MyActFlag = getActDecision(MyID)

        MyActFlag = True #TEST PURPOSE ONLY
        
        if MyActFlag == True:
            isPickObj = True
            newmoto.forward(FwdDutyCycle,FwdTime)
            newmoto.stop()
            if ObjDist < 0.8*PickDist:
                print('Energized')
                newmoto.energize()
                newmoto.forward(FwdDutyCycle,FwdTime)
                PickStatus = True
                pycomm.setRoboObjDist(MyID,0)
        elif MyActFlag == False:
            isPickObj = False
            PickStatus = False
            print('Picking False')
            pycomm.setRoboObjDist(MyID,0)
            #GetOut from the pick obj state and go in patroling
    return PickStatus, isPickObj
    
def getActDecision(MyID): 
    AllRoboID = ['R111', 'R105', 'R104']               
        
    R111ObjDist = pycomm.getRoboDB('R111','Dist')               #For Test Only
    R105ObjDist = pycomm.getRoboDB('R105','Dist')
    R104ObjDist = pycomm.getRoboDB('R104','Dist')               #For Test Only
        
    #R105ObjDist = 0
    R105ObjDist = int(R105ObjDist.decode())
    R111ObjDist = int(R111ObjDist.decode())
    R104ObjDist = int(R104ObjDist.decode())

    AllObjDist = [R111ObjDist, R105ObjDist, R104ObjDist]
    nzAllObjDist = [num for num in AllObjDist if num] #Remove the Zero from list
    #tempAllObjDist.remove(0)
    print('AllObj : nzAllObj',AllObjDist,nzAllObjDist)
    minObjDist = min(nzAllObjDist)
    ActRoboID = AllRoboID[AllObjDist.index(minObjDist)]
    print(ActRoboID)
    if MyID == ActRoboID:
        print(' MyActFlag Set')
        MyActFlag = True
    else:
        MyActFlag = False                       
    return MyActFlag

def stateGoStocker(MyID, MarkStat,PickStatus,MyMarkFlag):
    print('Dropping Object...')
    pycomm.setRoboObjDist(MyID,0)
    MyZone = MarkStat.get('MarkColor')
    pycomm.setRoboZone(MyID, MyZone)
    pycomm.setRoboAct(MyID,'DRP')

    MarkLoc = MarkStat.get('MarkLoc')
    if (MarkLoc == None):
        stateRotate('R')
    elif (MarkLoc == 'L'):
        newmoto.turnleft(Turn10DutyCycle,Turn10Time)
        newmoto.stop()
    elif(MarkLoc == 'R'):
        newmoto.turnright(Turn10DutyCycle,Turn10Time)
        newmoto.stop()
    elif(MarkLoc == 'C'):
        MarkDims = MarkStat.get('MarkDims')
        MarkDist = pyvision.MarkToCamDist(MarkDims)
        #print(MarkDist)
        newmoto.forward(FwdDutyCycle,FwdTime)
        newmoto.stop()
    elif(MarkLoc == 'B'):
        print('De-Energized')
        newmoto.deenergize()
        PickStatus = False
        newmoto.turnright(Turn180DutyCycle,Turn180Time)
        newmoto.stop()

        #FailState,FailedRoboID = checkRoboStates()
        FailState = 0
        if FailState == 0:
            MyMarkFlag = True
        if FailState > 0:
            newmoto.turnleft(Turn180DutyCycle,Turn180Time/2)
            newmoto.stop()
            newmoto.forward(FwdDutyCycle,5)
            newmoto.stop()
            newmoto.turnright(Turn180DutyCycle, Turn180Time/2)
            newmoto.stop()
            MyMarkFlag = not(MyMarkFlag)
    return PickStatus, MyMarkFlag

def stateRotate(MyID,MarkStat,Loc):
    print('Finding Marker...')
    MyZone = MarkStat.get('MarkColor')
    pycomm.setRoboZone(MyID, MyZone)
    pycomm.setRoboAct(MyID,'FND')

    if Loc == 'L':
        newmoto.turnleft(50,0.4)
        newmoto.stop()
    elif Loc == 'R':
        newmoto.turnright(50,0.4)
        newmoto.stop()
    return

def getMarkStat(InputImg,RoboID):
    if (RoboID == 'R111'):
        MarkCol = R111MarkCol
        MarkColLL = R111MarkColLL
        MarkColUL = R111MarkColUL
    if (RoboID == 'R105'):
        MarkCol = R105MarkCol
        MarkColLL = R105MarkColLL
        MarkColUL = R105MarkColUL
    if (RoboID == 'R104'):
        MarkCol = R104MarkCol
        MarkColLL = R104MarkColLL
        MarkColUL = R104MarkColUL

    MarkStat = pyvision.getMarkerStatus(InputImg,MarkCol,MarkColLL,MarkColUL)
    return MarkStat

def getObjStat(InputImg,RoboID):
    if (RoboID == 'R111'):
        ObjColLL = R111ObjColLL
        ObjColUL = R111ObjColUL
    if (RoboID == 'R105'):
        ObjColLL = R111ObjColLL
        ObjColUL = R111ObjColUL
    if (RoboID == 'R104'):
        ObjColLL = R111ObjColLL
        ObjColUL = R111ObjColUL

    ObjStat = pyvision.getObjStatus(InputImg,ObjColLL,ObjColUL)
    return ObjStat

def checkRoboStates():
    FailState = 0
    FailedRoboID = None

    Robo1State = pycomm.getRoboState('Robo1State')     #Robo 111
    Robo2State = pycomm.getRoboState('Robo2State')     #Robo 105
    Robo3State = pycomm.getRoboState('Robo3State')     #Robo 104

    if ('FALSE' in Robo1State):
        FailState = 1
        FailedRoboID = 'R111'
    if ('FALSE' in Robo2State):
        FailState = 2
        FailedRoboID = 'R105'
    if ('FALSE' in Robo3State):
        FailState = 3
        FailedRoboID = 'R104'
    if ('FALSE' in Robo1State) and ('FALSE' in Robo2State):       #For future development 
        FailState = 12
    if ('FALSE' in Robo1State) and ('FALSE' in Robo3State):       #For future development
        FailState = 13
    if ('FALSE' in Robo2State) and ('FALSE' in Robo3State):       #For future development
        FailState = 23

    print('Health of other Robos acquired...')
    return FailState,FailedRoboID

def setCameraBrightness(RoboID):
    if (RoboID == 'R111'):
        brightness = R111CameraBrightness
    if (RoboID == 'R105'):
        brightness = R105CameraBrightness
    if (RoboID == 'R104'):
        brightness = R104CameraBrightness

    return brightness

#Main Program
while True:
    #Call initialization module
    print('Initialization done...')

    RunPyVisionFlag = True

    while RunPyVisionFlag:

        # Capture Image
        camcls = pycamera.initPiCamera()
        brightness = setCameraBrightness(MyID)
        pycamera.capturePic(camcls,brightness)
        InputImg = cv2.imread('/home/pi/Documents/ColabIntel/img/1.jpg')

        # Check Robo States
        #FailState,FailedRoboID = checkRoboStates()       # Comment below 2 lines, if this is used 
        FailState = 0                                    # For Offline Testing Purpose
        FailedRoboID = None                              # For Offline Testing Purpose

        # Get Marker Status
        MyMarkStat = getMarkStat(InputImg,MyID)
        isMyMarkFound = MyMarkStat.get('isMarkFound')
        if (FailState == 0):
           isAnyMarkFound = isMyMarkFound
        if (FailState > 0):
            SecMarkStat = getMarkStat(InputImg,FailedRoboID)
            isSecMarkFound = SecMarkStat.get('isMarkFound')
            if (isMyMarkFound == False and isSecMarkFound == False):
                isAnyMarkFound = False
            else:
                isAnyMarkFound = True

        # Get Object Status
        if (AnyObjPickedStatus == False and isPickingObj == True):
            MyObjStat = getObjStat(InputImg,MyID)
            isMyObjFound = MyObjStat.get('isObjFound')
            if (FailState == 0):
                isAnyObjFound = isMyObjFound
            if (FailState > 0):
                SecObjStat = getObjStat(InputImg,FailedRoboID)
                isSecObjFound = SecObjStat.get('isObjFound')
                if (isMyObjFound == False or isSecObjFound == False):
                    isAnyObjFound = False
                else:
                    isAnyObjFound = True
        elif(AnyObjPickedStatus == False and isPickingObj == False):
            isAnyObjFound = False


        # Set Marker Status as per MyMarkFlag
        if (FailState == 0) and (MyMarkFlag == True):
            MarkStat = MyMarkStat
        elif (FailState > 0) and (MyMarkFlag == True):
            MarkStat = MyMarkStat
        elif (FailState > 0) and (MyMarkFlag == False):
            MarkStat = SecMarkStat
        #print ('MyMarkFlag=',MyMarkFlag)

        # Patroling
        if (isAnyMarkFound == True and isAnyObjFound == False and AnyObjPickedStatus == False):
            MyMarkFlag = statePatroling3(MyID,MarkStat,MyMarkFlag,brightness)

        # Picking the object
        if (isAnyObjFound == True and AnyObjPickedStatus == False):
            if (MyMarkFlag == True):
                AnyObjPickedStatus,isPickingObj= statePickObj(MyID,MarkStat,MyObjStat,AnyObjPickedStatus)
                print('isPickObject=',isPickingObj)
            elif (MyMarkFlag == False):
                AnyObjPickedStatus,isPickingObj = statePickObj(MyID, MarkStat,SecObjStat,AnyObjPickedStatus)

        # Dropping the object
        if (isAnyMarkFound == True and AnyObjPickedStatus == True):
            if (MyMarkFlag == True):
                AnyObjPickedStatus,MyMarkFlag = stateGoStocker(MyID,MarkStat,AnyObjPickedStatus,MyMarkFlag)
            elif (MyMarkFlag == False):
                AnyObjPickedStatus,MyMarkFlag = stateGoStocker(MyID,MarkStat,AnyObjPickedStatus,MyMarkFlag)

        # Finding the marker
        if (isAnyMarkFound == False or isAnyMarkFound == None):
            stateRotate(MyID,MarkStat,'R')
    else:
        RunPyVisionFlag = True
        print('Been here')
