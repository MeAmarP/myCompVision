

import sys
import time
import RPi.GPIO as GPIO

#def initPiMotor():
 #  GPIO.cleanup()
GPIO.setmode(GPIO.BOARD)
    #mode = GPIO.getmode()
GPIO.setwarnings(False)
MAFwd = 11
MARev = 13
MBFwd = 15
MBRev = 16
MAEnable=32
MBEnable=12
Pickup_Energising=18
sleeptime=5

GPIO.setup(MAFwd,GPIO.OUT)
GPIO.setup(MARev,GPIO.OUT)
GPIO.setup(MBFwd,GPIO.OUT)
GPIO.setup(MBRev,GPIO.OUT)
GPIO.setup(MAEnable,GPIO.OUT)
GPIO.setup(MBEnable,GPIO.OUT)
GPIO.setup(Pickup_Energising,GPIO.OUT)

duty_range_positive=100
duty_range_negative=-100

PWM_A = GPIO.PWM(32,200)
PWM_B = GPIO.PWM(12,200)

Zero_deg = 0.5
Full_deg = 2.5
duty_range = 100

PWM_A.start(1)
PWM_B.start(1)

def Motor_Forward_Turn_Left():	
    GPIO.output(11, GPIO.HIGH)
    GPIO.output(13, GPIO.LOW)
    GPIO.output(15, GPIO.LOW)
    GPIO.output(16, GPIO.HIGH)
    print("Motor Forward Turning Left")
   # PWM_A.ChangeDutyCycle(duty_cycle)   
   # PWM_B.ChangeDutyCycle(duty_cycle)    
    #GPIO.cleanup()
    return

def Motor_Forward_Turn_Right():	
    GPIO.output(11, GPIO.LOW)
    GPIO.output(13, GPIO.HIGH)
    GPIO.output(15, GPIO.HIGH)
    GPIO.output(16, GPIO.LOW)
    print("Motor Forward Turning Right")
    #PWM_A.ChangeDutyCycle(duty_cycle)   
    #PWM_B.ChangeDutyCycle(duty_cycle)
    #GPIO.cleanup()
    return

def Motor_A_and_B_Forward(x):
    #import time
    GPIO.output(11, GPIO.HIGH)
    GPIO.output(13, GPIO.LOW)
    GPIO.output(15, GPIO.HIGH)
    GPIO.output(16,GPIO.LOW)
    print("Moving Motor A and B Forward")
    time.sleep(x)
    GPIO.output(11, GPIO.LOW)
    GPIO.output(15, GPIO.LOW)
    #	GPIO.cleanup()
    return

def Motor_A_and_B_Reversed(x):
    GPIO.output(11, GPIO.LOW)
    GPIO.output(13, GPIO.HIGH)
    GPIO.output(15, GPIO.LOW)
    GPIO.output(16,GPIO.HIGH)	
    print("Moving Motor A and B Reversed")
    time.sleep(x)
    GPIO.output(13, GPIO.LOW)
    GPIO.output(16, GPIO.LOW)
    #GPIO.cleanup()
    return

def Energize(x):
    GPIO.output(Pickup_Energising, GPIO.HIGH)
    print("Pickup Block Activated")
    time.sleep(x)
    return

def De_Energize(x):	
    GPIO.output(Pickup_Energising, GPIO.LOW)
    print("Pickup Block Deactivated")
    time.sleep(x)
    return

def Make_Zero_Duty():
    PWM_A.ChangeDutyCycle(0)  
    PWM_B.ChangeDutyCycle(0)
    return

def Make_Normal_Duty():
    PWM_A.ChangeDutyCycle(100)  
    PWM_B.ChangeDutyCycle(100)
    return


Motor_A_and_B_Forward(5)
time.sleep(2)
