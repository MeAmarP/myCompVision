# -*- coding: utf-8 -*
"""
pyvision module
Version: 2.00
Created on Mon Nov 5 20:34:01 2018
@author: apotdar
"""
import numpy as np
import cv2

# =============================================================================
# def getObjStatus(InputImg,ObjColorLL,ObjColorUL)
# =============================================================================
def getObjStatus(InputImg,ObjColorLL,ObjColorUL):
    #print('Entering getObjStatus...')
    ColorLower = np.array(ObjColorLL)
    ColorUpper = np.array(ObjColorUL)
    #Red1Lower = np.array([0,50,50])
    #Red1Upper = np.array([10,255,255])
    #Red2Lower = np.array([170,50,50])
    #Red2Upper = np.array([180,255,255])
    ImgHeight,ImgWidth = InputImg.shape[:2]

    #Object Detection ROIs
    CenterVal = ImgWidth / 2
    LowerCenterVal = CenterVal - (CenterVal*0.2) #20Percent Below Center in HoriDir
    UpperCenterVal = CenterVal + (CenterVal*0.2) #20Percent Above Center in HoriDir

    ImgHSV = cv2.cvtColor(InputImg,cv2.COLOR_BGR2HSV)

    #Create Mask Values for Color
    ColorMask = cv2.inRange(ImgHSV,ColorLower,ColorUpper)

    #Some Morph Opertations
    Kernel = np.ones((5,5),"uint8")
    ColorMask = cv2.dilate(ColorMask,Kernel)

    #Init List Vars
    ObjStatsDict = dict(isObjFound=False,ObjLoc=None,ObjDims=[])

    #Find Contours Colored Region
    (_,contours,hierarchy)=cv2.findContours(ColorMask,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

    for objs in contours:
        ObjArea =  cv2.contourArea(objs)
        if (ObjArea > 300):
            x,y,w,h = cv2.boundingRect(objs)
            RectDims=[x,y,w,h]
            ObjStatsDict.update({'ObjDims':RectDims})
            if(x+w/2 < LowerCenterVal):
                ObjStatsDict.update({'isObjFound':True})
                ObjStatsDict.update({'ObjLoc':'L'})
                break
            elif(x+w/2 > UpperCenterVal):
                ObjStatsDict.update({'isObjFound':True})
                ObjStatsDict.update({'ObjLoc':'R'})
                break
            elif(x+w/2 > LowerCenterVal and x+w/2 < UpperCenterVal):
                ObjStatsDict.update({'isObjFound':True})
                ObjStatsDict.update({'ObjLoc':'C'})
                break
    print(ObjStatsDict)
    #print('Leaving getObjStatus...')
    return ObjStatsDict

# =============================================================================
# def getMarkerStatus(InputImg,MarkColor,MarkColorLL,MarkColorUL)
# =============================================================================
def getMarkerStatus(InputImg,MarkColor,MarkColorLL,MarkColorUL):
    #print('Entering getMarkerStatus...')
    #Marker Color Assignment
    ColorLower = np.array(MarkColorLL)
    ColorUpper = np.array(MarkColorUL)
    #GreenLower = np.array([40,100,100])
    #GreenUpper = np.array([80,255,255])
    ImgHeight,ImgWidth = InputImg.shape[:2]

    #Marker Detection ROIs
    CenterVal = ImgWidth / 2
    LowerCenterVal = CenterVal - (CenterVal*0.3) #30Percent Below Center in HoriDir
    UpperCenterVal = CenterVal + (CenterVal*0.3) #30Percent Above Center in HoriDir
    MarkMaxPxlWidth = 280
    MarkMaxPxlHeight = 200

    ImgHSV = cv2.cvtColor(InputImg,cv2.COLOR_BGR2HSV)

    #Create Mask Values for Color
    ColorMask = cv2.inRange(ImgHSV,ColorLower,ColorUpper)
	
    #Some Morph Opertations
    Kernel = np.ones((5,5),"uint8")
    ColorMask = cv2.dilate(ColorMask,Kernel)

    #Init List Vars
    MarkerStatsDict = dict(isMarkFound=False,MarkColor=MarkColor,MarkLoc=None,MarkDims=[],MarkCenter=[])

    #Find Contours Colored Region
    (_,contours,hierarchy)=cv2.findContours(ColorMask,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    if len(contours) ==  0:
        pass
        #MarkerStatsDict.update({'isMarkFound':True})
        #MarkerStatsDict.update({'MarkLoc':'B'})
    else:
        for marks in contours:
            MarkerArea =  cv2.contourArea(marks)
            if (MarkerArea > 300):
                x,y,w,h = cv2.boundingRect(marks)
                RectDims=[x,y,w,h]
                if len(RectDims)>0:
                    MarkerStatsDict.update({'MarkDims':RectDims})
                    MarkerStatsDict.update({'MarkCenter':[x+w/2,y+h/2]})
                    MarkerStatsDict.update({'MarkColor':MarkColor})
                    if(w > MarkMaxPxlWidth and h > MarkMaxPxlHeight):
                        MarkerStatsDict.update({'isMarkFound':True})
                        MarkerStatsDict.update({'MarkLoc':'B'})
                        break
                    elif(x+w/2 < LowerCenterVal):
                        MarkerStatsDict.update({'isMarkFound':True})
                        MarkerStatsDict.update({'MarkLoc':'L'})
                        break
                    elif(x+w/2 > UpperCenterVal):
                        MarkerStatsDict.update({'isMarkFound':True})
                        MarkerStatsDict.update({'MarkLoc':'R'})
                        break
                    elif(x+w/2 > LowerCenterVal and x+w/2 < UpperCenterVal):
                        MarkerStatsDict.update({'isMarkFound':True})
                        MarkerStatsDict.update({'MarkLoc':'C'})
                        break

    print(MarkerStatsDict)
    #print('Leaving getMarkerStatus...')
    return MarkerStatsDict

# =============================================================================
# def ObjToCamDist(ObjDims)
# =============================================================================
def ObjToCamDist(ObjDims):
    #Define Related Constants
    CamFocLen =  68             #mm
    ObjRealWidth = 400          #mm
    ObjPxlWidth = ObjDims[2]    #Pixels
    distance = (ObjRealWidth * CamFocLen) / (ObjPxlWidth)
    return round(distance)

# =============================================================================
# def MarkToCamDist(ObjDims)
# =============================================================================
def MarkToCamDist(MarkDims):
    #Define Related Constants
    CamFocLen =  68             #mm
    MarkRealWidth = 720         #mm
    MarkPxlWidth = MarkDims[2]  #Pixels
    distance = (MarkRealWidth * CamFocLen) / (MarkPxlWidth)
    return round(distance)
