import pycamera
import time
#from threading import Thread


start = time.time() # Run Timer

#global camcls
#initTH = Thread(target=pycamera.initPiCamera)
#initTH.start()

camcls = pycamera.initPiCamera()
pycamera.capturePic(camcls)

#initTh.join()

#Get Total Execution Time
end = time.time() - start
print('Total Exec Time: ', end)

