# -*- coding: utf-8 -*-
"""
pyvision module
Version: 2.00
Created on Mon Nov  5 20:34:01 2018
@author: apotdar
"""

import numpy as np
import cv2

# =============================================================================
# def getObjStatus(InputImg)
# =============================================================================
def getObjStatus(InputImg):    
    #(0-10)
    Red1Lower = np.array([0,50,50])
    Red1Upper = np.array([10,255,255])
    #(170-180)
    Red2Lower = np.array([170,50,50])
    Red2Upper = np.array([180,255,255])
    
    ImgHeight,ImgWidth = InputImg.shape[:2]
    
    #Object Detection ROIs
    CenterVal = ImgWidth / 2
    LowerCenterVal = CenterVal - (CenterVal*0.2) #20Percent Below Center in HoriDir
    UpperCenterVal = CenterVal + (CenterVal*0.2) #20Percent Above Center in HoriDir
    
    ImgHSV = cv2.cvtColor(InputImg,cv2.COLOR_BGR2HSV)
    
    #Create Massk Values for Red
    Red1Mask = cv2.inRange(ImgHSV,Red1Lower,Red1Upper)   
    Red2Mask = cv2.inRange(ImgHSV,Red2Lower,Red2Upper)   
    RedMask = Red1Mask+Red2Mask

    # Some Morph Opertations
    Kernel = np.ones((5,5),"uint8")
    RedMask = cv2.dilate(RedMask,Kernel)
    
    #Init List Vars
    #ObjFound = False
    #ObjLoc = None
    #ObjStats = []
    ObjStatsDict = dict(isObjFound=False,ObjLoc=None,ObjDims=[])

    # Find Contours
    (_,contours,hierarchy)=cv2.findContours(RedMask,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    
    for objs in contours:
        ObjArea =  cv2.contourArea(objs)    
        if (ObjArea > 300):
            x,y,w,h = cv2.boundingRect(objs)
            RectDims=[x,y,w,h]
            ObjStatsDict.update({'ObjDims':RectDims})
            if(x < LowerCenterVal):                
                ObjStatsDict.update({'isObjFound':True})
                ObjStatsDict.update({'ObjLoc':'L'})                
                break
            elif(x > UpperCenterVal):
                ObjStatsDict.update({'isObjFound':True})
                ObjStatsDict.update({'ObjLoc':'R'})                
                break
            elif(x > LowerCenterVal and x < UpperCenterVal):                
                ObjStatsDict.update({'isObjFound':True})                
                ObjStatsDict.update({'ObjLoc':'C'})                
                break        
    return ObjStatsDict

# =============================================================================
# def getGreenMarkerStatus(InputImg)    
# =============================================================================
def getGreenMarkerStatus(InputImg):
    #Marker Colors Green/Blue/
    GreenLower = np.array([40,100,100])
    GreenUpper = np.array([80,255,255])
    ImgHeight,ImgWidth = InputImg.shape[:2]
    
    #Marker Detection ROIs
    CenterVal = ImgWidth / 2
    LowerCenterVal = CenterVal - (CenterVal*0.2) #20Percent Below Center in HoriDir
    UpperCenterVal = CenterVal + (CenterVal*0.2) #20Percent Above Center in HoriDir
    
    ImgHSV = cv2.cvtColor(InputImg,cv2.COLOR_BGR2HSV)
    
    #Create Mask Values for Green
    GreenMask = cv2.inRange(ImgHSV,GreenLower,GreenUpper)       
    # Some Morph Opertations
    Kernel = np.ones((5,5),"uint8")
    GreenMask = cv2.dilate(GreenMask,Kernel)
    
    #Init List Vars
    #MarkerFound = False
    #MarkerLoc = None
    #MarkerStats = []
    GreenMarkerStatsDict = dict(isMarkerFound=False,MarkerColor='G',MarkerLoc=None,MarkerDims=[])

    # Find Contours Green Region
    (_,contours,hierarchy)=cv2.findContours(GreenMask,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)    
    for marks in contours:
        MarkerArea =  cv2.contourArea(marks)    
        if (MarkerArea > 300):
            x,y,w,h = cv2.boundingRect(marks)
            RectDims=[x,y,w,h]
            GreenMarkerStatsDict.update({'MarkDims':RectDims})
            if(x < LowerCenterVal):                
                GreenMarkerStatsDict.update({'isMarkFound':True})                
                GreenMarkerStatsDict.update({'MarkLoc':'L'})                
                break
            elif(x > UpperCenterVal):                
                GreenMarkerStatsDict.update({'isMarkFound':True})                
                GreenMarkerStatsDict.update({'MarkLoc':'R'})                
                break
            elif(x > LowerCenterVal and x < UpperCenterVal):                
                GreenMarkerStatsDict.update({'isMarkFound':True})                
                GreenMarkerStatsDict.update({'MarkLoc':'C'})                
                break                            
    return GreenMarkerStatsDict



# =============================================================================
# def getBlueMarkerStatus(InputImg)
# =============================================================================
def getBlueMarkerStatus(InputImg):
    #Marker Colors Green/Blue/
    BlueLower = np.array([60,100,100])
    BlueUpper = np.array([180,255,255])
    
    ImgHeight,ImgWidth = InputImg.shape[:2]    
    #Marker Detection ROIs
    CenterVal = ImgWidth / 2
    LowerCenterVal = CenterVal - (CenterVal*0.2) #20Percent Below Center in HoriDir
    UpperCenterVal = CenterVal + (CenterVal*0.2) #20Percent Above Center in HoriDir
    
    ImgHSV = cv2.cvtColor(InputImg,cv2.COLOR_BGR2HSV)
    
    #Create Mask Values for Green
    BlueMask = cv2.inRange(ImgHSV,BlueLower,BlueUpper)       
    # Some Morph Opertations
    Kernel = np.ones((5,5),"uint8")
    BlueMask = cv2.dilate(BlueMask,Kernel)
    
    #Init List Vars
    #MarkerFound = False
    #MarkerLoc = None
    #MarkerStats = []
    BlueMarkerStatsDict = dict(isMarkerFound=False,MarkerColor='B',MarkerLoc=None,MarkerDims=[])

    # Find Contours Green Region
    (_,contours,hierarchy)=cv2.findContours(BlueMask,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)    
    for marks in contours:
        MarkerArea =  cv2.contourArea(marks)    
        if (MarkerArea > 300):
            x,y,w,h = cv2.boundingRect(marks)
            RectDims=[x,y,w,h]
            BlueMarkerStatsDict.update({'MarkDims':RectDims})
            if(x < LowerCenterVal):                
                BlueMarkerStatsDict.update({'isMarkFound':True})                
                BlueMarkerStatsDict.update({'MarkLoc':'L'})                
                break
            elif(x > UpperCenterVal):                
                BlueMarkerStatsDict.update({'isMarkFound':True})                
                BlueMarkerStatsDict.update({'MarkLoc':'R'})                
                break
            elif(x > LowerCenterVal and x < UpperCenterVal):                
                BlueMarkerStatsDict.update({'isMarkFound':True})                
                BlueMarkerStatsDict.update({'MarkLoc':'C'})                
                break                            
    return BlueMarkerStatsDict




# =============================================================================
# def ObjToCamDist(ObjDims)
# =============================================================================
def ObjToCamDist(ObjDims):
    #Define Related Constants
    CamFocLen = 4.03            #mm
    ObjRealWidth = 450          #mm
    ObjPxlWidth = ObjDims[2]    #Pixels
    CamSenPxlSize = 1.12e-3     #mm
    
    distance = (ObjRealWidth * CamFocLen) / (ObjPxlWidth * CamSenPxlSize)
    return distance