#from time import sleep
import picamera
from time import sleep

brightness = 70                                 # for robo111=55,robo105=70,robo104=70
def initPiCamera(): 
    cam = picamera.PiCamera()
    cam.resolution = (640,480)
    return cam

def capturePic(cam,brightness):
    cam.brightness = brightness
    #cam.contrast = 50
    #cam.saturation = 20
    #cam.image_effect = 'none'
    cam.awb_mode = 'fluorescent'
    cam.rotation = 180

    sleep(1.5)        # =1.5 on Full Charge, else =0.75
    cam.capture('/home/pi/Documents/2.jpg')
    cam.close()

def main():
	CamCls = initPiCamera()
	capturePic(CamCls,60)

if __name__ == '__main__':
	main()
