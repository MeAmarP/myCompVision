import pycamera
import newmoto
import pyvision
import cv2
import time

#Init Vars
RLObjColLL = [0,50,50]                    # Red Object Lower Limit
RLObjColUL = [10,255,255]                 # Red Object Upper Limit
RLMarkColLL = [40,100,100]                # Green Marker Lower Limit
RLMarkColUL = [80,255,255]                # Green Marker Upper Limit

RMObjColLL = [35,150,150]                 # Fluorescent Object Lower Limit... Check
RMObjColUL = [55,200,255]                 # Fluorescent Object Upper Limit... Check
RMMarkColLL = [98,80,80]                  # Blue Marker Lower Limit... Check
RMMarkColUL = [110,255,255]               # Blue Marker Upper Limit... Check

RRObjColLL = [20,160,20]                  # Brown Object Lower Limit... Check
RRObjColUL = [30,255,255]                 # Brown Object Upper Limit... Check
RRMarkColLL = [2,160,160]                 # Orange Marker Lower Limit... Check
RRMarkColUL = [40,255,255]                # Orange Marker Upper Limit... Check

MyObjPickedStatus = False
AnyObjPickedStatus = False

Turn180DutyCycle = 90
Turn180Time = 1.70                        # =1.70 On Full-Charge, else use 2
Turn10DutyCycle = 50
Turn10Time = 0.20                         # =0.25 on Full-Charge, else use 0.3
FwdDutyCycle = 100
FwdTime = 0.70                            # =0.70 On Full-Charge, else use 1
PickDist = 300


#Scenarios
RoboLeft = True
RoboMiddle = True
RoboRight = True
LoopDrn = None

def statePatroling(MarkStat):
    print('Patroling...')
    MarkLoc = MarkStat.get('MarkLoc')
    #MarkColor = MarkStat.get('MarkerColor')
    if(MarkLoc == 'L'):
        newmoto.turnleft(Turn10DutyCycle,Turn10Time)
        newmoto.stop()
    elif(MarkLoc == 'R'):
        newmoto.turnright(Turn10DutyCycle,Turn10Time)
        newmoto.stop()
    elif(MarkLoc == 'C'):
        MarkDims = MarkStat.get('MarkDims')
        MarkDist = pyvision.MarkToCamDist(MarkDims)
        #print(MarkDist)
        newmoto.forward(FwdDutyCycle,FwdTime)
        newmoto.stop()
    elif(MarkLoc == 'B'):
        newmoto.turnright(Turn180DutyCycle,Turn180Time)
        newmoto.stop()
    return

def statePickObj(ObjStat,PickStatus):
    print('Picking Obj...')
    ObjLoc = ObjStat.get('ObjLoc')
    if (ObjLoc == 'L'):
        newmoto.turnleft(Turn10DutyCycle,Turn10Time)
        newmoto.stop()
    elif(ObjLoc=='R'):
        newmoto.turnright(Turn10DutyCycle,Turn10Time)
        newmoto.stop()
    elif(ObjLoc=='C'):
        ObjDims = ObjStat.get('ObjDims')
        ObjDist = pyvision.ObjToCamDist(ObjDims)
        #print(ObjDist)
        newmoto.forward(FwdDutyCycle,FwdTime)
        newmoto.stop()
        if ObjDist < PickDist:
            print('Energized')
            newmoto.energize()
            newmoto.forward(FwdDutyCycle,FwdTime)
            PickStatus = True
    return PickStatus

def stateGoStocker(MarkStat,PickStatus):
    print('Dropping Obj...')
    MarkLoc = MarkStat.get('MarkLoc')
    if (MarkLoc == None):
        stateRotate('R')
    elif (MarkLoc == 'L'):
        newmoto.turnleft(Turn10DutyCycle,Turn10Time)
        newmoto.stop()
    elif(MarkLoc == 'R'):
        newmoto.turnright(Turn10DutyCycle,Turn10Time)
        newmoto.stop()
    elif(MarkLoc == 'C'):
        MarkDims = MarkStat.get('MarkDims')
        MarkDist = pyvision.MarkToCamDist(MarkDims)
        #print(MarkDist)
        newmoto.forward(FwdDutyCycle,FwdTime)
        newmoto.stop()
    elif(MarkLoc == 'B'):
        print('De-Energized')
        newmoto.deenergize()
        PickStatus = False
        newmoto.turnright(Turn180DutyCycle,Turn180Time) #Rotate-180Deg State
        newmoto.stop()
    return PickStatus

def stateRotate(Loc):
    print('Finding Marker...')
    if Loc == 'L':
        newmoto.turnleft(50,0.4)
        newmoto.stop()
    elif Loc == 'R':
        newmoto.turnright(50,0.4)
        newmoto.stop()
    return

def findLoopDrn(Mark2Stat,LoopDrn):
    print('Finding Loop Direction...')
    isMark2Found = Mark2Stat.get('isMarkFound')
    if (isMark2Found == True):
        LoopDrn = Mark2Stat.get('MarkLoc')
    elif (LoopDrn == 'tmp'):
        LoopDrn = 'L'
    elif (isMark2Found == False or isMark2Found == None):
        newmoto.turnright(Turn180DutyCycle,Turn180Time/4)
        newmoto.stop()
        LoopDrn = 'tmp'
    return LoopDrn

def statePatroling2(Mark1Stat,Mark2Stat,LoopDrn):
    print('Patroling-2...')
    isMark1Found = Mark1Stat.get('isMarkFound')
    isMark2Found = Mark2Stat.get('isMarkFound')

    if (isMark1Found == True):
        MarkLoc = Mark1Stat.get('MarkLoc')
    elif (isMark2Found == True):
        MarkLoc = Mark2Stat.get('MarkLoc')

    if(MarkLoc == 'L'):
        newmoto.turnleft(Turn10DutyCycle,Turn10Time)
        newmoto.stop()
    elif(MarkLoc == 'R'):
        newmoto.turnright(Turn10DutyCycle,Turn10Time)
        newmoto.stop()
    elif(MarkLoc == 'C'):
        MarkDims = MarkStat.get('MarkDims')
        MarkDist = pyvision.MarkToCamDist(MarkDims)
        #print(MarkDist)
        newmoto.forward(FwdDutyCycle,FwdTime)
        newmoto.stop()
    elif(MarkLoc == 'B'):
        if (LoopDrn == 'L'):
            newmoto.turnleft(Turn180DutyCycle,Turn180Time/2)
            newmoto.stop()
            newmoto.forward(FwdDutyCycle,2*FwdTime)
            newmoto.stop()
            newmoto.turnleft(Turn180DutyCycle,Turn180Time/2)
            newmoto.stop()
        else:
            newmoto.turnright(Turn180DutyCycle,Turn180Time/2)
            newmoto.stop()
            newmoto.forward(FwdDutyCycle,2*FwdTime)
            newmoto.stop()
            newmoto.turnright(Turn180DutyCycle,Turn180Time/2)
            newmoto.stop()
    return

#Main Program
while True:
    #Call initialization module
    print('Initialization done...')

    RunPyVisionFlag = True

    while RunPyVisionFlag:
        start = time.time()
        camcls = pycamera.initPiCamera()
        pycamera.capturePic(camcls)

        InputImg = cv2.imread('/home/pi/Documents/ColabIntel/img/1.jpg')

        #Get Health Status of other Robos
        print('Health of other Robos acquired...')

        if (RoboLeft == True) and (RoboMiddle == True) and (RoboRight == True) and (AnyObjPickedStatus == False):

            LoopDrn = None
            MyMarkColLL = RRMarkColLL
            MyMarkColUL = RRMarkColUL
            MyObjColLL = RRObjColLL
            MyObjColUL = RRObjColUL

            MyMarkStat = pyvision.getMarkerStatus(InputImg,MyMarkColLL,MyMarkColUL)
            isMyMarkFound = MyMarkStat.get('isMarkFound')

            if (MyObjPickedStatus == False):
                MyObjStat = pyvision.getObjStatus(InputImg,MyObjColLL,MyObjColUL)
                isMyObjFound = MyObjStat.get('isObjFound')

            if (isMyMarkFound == True and isMyObjFound == False and MyObjPickedStatus == False):
                statePatroling(MyMarkStat)

            if (isMyObjFound == True and MyObjPickedStatus == False):
                MyObjPickedStatus = statePickObj(MyObjStat,MyObjPickedStatus)

            if (isMyMarkFound == True and MyObjPickedStatus == True):
                MyObjPickedStatus = stateGoStocker(MyMarkStat,MyObjPickedStatus)

            if (isMyMarkFound == False or isMyMarkFound == None):
                stateRotate('R')

        if (RoboLeft == True) and (RoboMiddle == False) and (RoboRight == True) and (MyObjPickedStatus == False):

            MyMarkColLL = RLMarkColLL
            MyMarkColUL = RLMarkColUL
            MyObjColLL = RLObjColLL
            MyObjColUL = RLObjColUL
            SecMarkColLL = RMMarkColLL
            SecMarkColUL = RMMarkColUL
            SecObjColLL = RMObjColLL
            SecObjColUL = RMObjColUL

            MyMarkStat = pyvision.getMarkerStatus(InputImg,MyMarkColLL,MyMarkColUL)
            isMyMarkFound = MyMarkStat.get('isMarkFound')
            SecMarkStat = pyvision.getMarkerStatus(InputImg,SecMarkColLL,SecMarkColUL)
            isSecMarkFound = SecMarkStat.get('isMarkFound')
            if (isMyMarkFound == True or isSecMarkFound == True):
                isAnyMarkFound = True
            else:
                isAnyMarkFound = False

            if (LoopDrn == None or LoopDrn == 'tmp'):
                findLoopDrn(SecMarkStat,LoopDrn)
                print('LoopDrn=',LoopDrn)

            if (AnyObjPickedStatus == False):
                MyObjStat = pyvision.getObjStatus(InputImg,MyObjColLL,MyObjColUL)
                isMyObjFound = MyObjStat.get('isObjFound')
                SecObjStat = pyvision.getObjStatus(InputImg,SecObjColLL,SecObjColUL)
                isSecObjFound = SecObjStat.get('isObjFound')
                if (isMyObjFound == True or isSecObjFound == True):
                    isAnyObjFound = True
                else:
                    isAnyObjFound = False

            if (isAnyMarkFound == True and isAnyObjFound == False and AnyObjPickedStatus == False):
                statePatroling2(MyMarkStat,SecMarkStat,LoopDrn)

            if (isMyObjFound == True and AnyObjPickedStatus == False):
                AnyObjPickedStatus = statePickObj(MyObjStat,AnyObjPickedStatus)
            elif (isSecObjFound == True and AnyObjPickedStatus == False):
                AnyObjPickedStatus = statePickObj(SecObjStat,AnyObjPickedStatus)

            if (isMyMarkFound == True and AnyObjPickedStatus == True):
                AnyObjPickedStatus = stateGoStocker(MyMarkStat,AnyObjPickedStatus)
            elif (isSecMarkFound == True and AnyObjPickedStatus == True):
                AnyObjPickedStatus = stateGoStocker(SecMarkStat,AnyObjPickedStatus)

            if (isAnyMarkFound == False or isAnyMarkFound == None):
                stateRotate('R')

    else:
        RunPyVisionFlag = True
        print('Been here')
