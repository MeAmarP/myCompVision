import newmoto
import time
import threading


def robo_turn():
    newmoto.forward(100,10)
    newmoto.stop()
#    newmoto.turnleft(50,1)
#    newmoto.stop()
#    newmoto.turnright(50,1)
#    newmoto.stop()
    return

if __name__ == '__main__':
    robo_turn()


