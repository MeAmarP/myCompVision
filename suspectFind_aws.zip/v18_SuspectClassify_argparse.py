#!/usr/bin/env python
# -*- coding: utf-8 -*-
#  Copyright 2019 AMAR P <amar.potdar@capgemini.com>
#  Created On: 11th July 2019

'''
- Added argparse for command line execution..
'''
#from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input
from tensorflow.keras.layers import Dense, Flatten, Dropout
from tensorflow.keras.layers import LSTM
from tensorflow.keras.models import Sequential
from tensorflow.keras.optimizers import Adam, RMSprop
from tensorflow.keras.applications.mobilenet_v2 import MobileNetV2, preprocess_input

import numpy as np

import time
from tqdm import tqdm
import operator
import glob

#import matplotlib.pyplot as plt


import tensorflow as tf
tf.logging.set_verbosity(tf.logging.ERROR)

import argparse




parser = argparse.ArgumentParser(description='Real-Time activity Detection Algo')
parser.add_argument('--videofilename','-vn',
                    required=True,
                    dest='VNAME',
                    help='Provide Video File Name',
                    default='act_normal_9' )

parser.add_argument('--mobnum','-mn',
                    dest='MOBNUM',
                    help='Provide User Mobile Number')

args = parser.parse_args()


def initFeatureModel():
    """
    Build and Init Feature/Base Model, will be used for feature extraction from
    images
    """
    featureModel = MobileNetV2(weights='imagenet',
                             include_top=False,
                             pooling='avg')
    return featureModel
     
def initPredictModel(pathPretrainedWeights,InputShape,NClasses):
    """
    Build and Initialize Prediction model
    """
    #Define model/network Architecture
    FinModel = Sequential()
    FinModel.add(LSTM(1280, return_sequences=False,
                   input_shape=InputShape,
                   activation='tanh',
                   recurrent_activation='sigmoid'))
    FinModel.add(Dense(512, activation='relu'))
    FinModel.add(Dropout(0.5))
    FinModel.add(Dense(NClasses, activation='softmax'))    
    #Add pretraied Weights
    FinModel.load_weights(pathPretrainedWeights)
    
    optimizer = Adam(lr=1e-5, decay=1e-6)
    FinModel.compile(loss='categorical_crossentropy', optimizer=optimizer,metrics=['accuracy'])
    return FinModel
    
def realTimePredict(npFeatVect,PredictModel):
    AllProbs = PredictModel.predict(np.expand_dims(npFeatVect, axis=0))      
    print_class_from_prediction(np.squeeze(AllProbs, axis=0))
    
def notifyActivity_SMS(recipeint_mobnum):
    str_mobnum = str(recipeint_mobnum)
    import requests
    url = "https://www.fast2sms.com/dev/bulk"
    querystring = {"authorization":"17VQSGeXHPfNlcR4BnFdJvWATgoMq2wbaj6I0uKOpy3ki5hsCL2tfMjGa5lNLDYvWyheFXi0UuK3cr4x",
               "sender_id":"FSTSMS",
               "message":"Warning! Suspicious Activity@CAM-007",
               "language":"english",
               "route":"p",
               "numbers":""} #Dr.Sampath 7798359389
    querystring['numbers'] = str_mobnum
    headers ={'cache-control': "no-cache"}
    response = requests.request("GET", url, headers=headers, params=querystring)
    return

def print_class_from_prediction(predictions, nb_to_return=5):
    """Given a prediction, print the top classes."""
    # Get the prediction for each label.
    classes = ['normal','suspect']
    label_predictions = {}
    for i, label in enumerate(classes):
        label_predictions[label] = predictions[i]

    # Now sort them.
    sorted_lps = sorted(
        label_predictions.items(),
        key=operator.itemgetter(1),
        reverse=True
    )
    result = sorted_lps[0][0]
    result= result.upper()
    return result
        
def getPathToFeatVect(video_file_name):
    filename = video_file_name
    AllFeatPaths = glob.glob('data/*.npy')
    path_to_feat = [path for path in AllFeatPaths if filename in path]
    return path_to_feat[0]

#=======================================================================
#Main Prog
#=======================================================================

def main():
    # Constants
    PATH_WEIGHTS = 'weights/lstm-features.011-0.295.h5'
    FEATURE_SHAPE = (40,1280)
    NB_CLASSES = 2
    
    #video_file_name = 'act_normal_9'
    video_file_name = args.VNAME
    try:
        print('Initializing Prediction Model...')
        predicModel = initPredictModel(PATH_WEIGHTS,FEATURE_SHAPE,NB_CLASSES)
        print('Start Predicting')
        path_to_feat_vect = getPathToFeatVect(video_file_name)
        npFeatVect = np.load(path_to_feat_vect)
        realTimePredict(npFeatVect,predicModel)    
    except KeyboardInterrupt:
        print('Do Some Exception Handling Here!!')        
    return
               
if __name__ == "__main__":
    main()