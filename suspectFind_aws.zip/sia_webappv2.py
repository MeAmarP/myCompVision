# -*- coding: utf-8 -*-
"""
Created on Mon Jul 15 11:58:27 2019
@author: apotdar

"""

import numpy as np
import glob
from flask import Flask, jsonify
import v2_SuspectClassify
import FindShoplifter
#===============================Constants======================================


#=============================App utility funcs================================
app = Flask(__name__) 

@app.route("/")
@app.route("/sia/runapp/",methods=['GET','POST'])
def testhello():
    return "<h1>Not Much Going On Here...</h1>"


def getPathToFeatVect(filename,appTo):
    """
    TODO:
        Exception handling for filename conflicts
        or
        Exception handling for .npy not found
    """
    if appTo == 'findsuspect':
        AllFeatPath = glob.glob('data/*.npy')
    elif appTo == 'findshoplift':
        AllFeatPath = glob.glob('data/shoplift/*.npy')
    path_to_feat = [fpath for fpath in AllFeatPath if filename in fpath][0]
    return path_to_feat


def notifyActivity_SMS(recipeint_mobnum):
    """
    """
    str_mobnum = str(recipeint_mobnum)
    import requests
    url = "https://www.fast2sms.com/dev/bulk"
    querystring = {"authorization":"17VQSGeXHPfNlcR4BnFdJvWATgoMq2wbaj6I0uKOpy3ki5hsCL2tfMjGa5lNLDYvWyheFXi0UuK3cr4x",
               "sender_id":"FSTSMS",
               "message":"Warning! Suspicious Activity",
               "language":"english",
               "route":"p",
               "numbers":""} #Dr.Sampath 7798359389
    querystring['numbers'] = str_mobnum
    headers ={'cache-control': "no-cache"}
    response = requests.request("GET", 
                                url, 
                                headers=headers, 
                                params=querystring,
                                verify=False)
    print(response)
    #response = "<h1>SMS Alert Send to "+str(recipeint_mobnum)+"</h1>"
    return response

#===============================MAIN===========================================
@app.route("/sia/findsuspect/<fname_mobnum>",methods=['GET'])
def SiaAppFindSupect(fname_mobnum):
    """Starts Sia app for suspect activity prediction and returns result as json object.
    
    Args:
    videofilename (string): Name of the video file
    mobnum (string): Mobile number of a user to get SUSPECT activity notification
    
    Returns:
    json_obj: results of prediction on videofile.
    
    """
    results = {'act':None,
           'alarm_stat':None}
    PATH_WEIGHTS = 'weights/lstm-features.011-0.295.h5'
    FEATURE_SHAPE = (40,1280)
    NB_CLASSES = 2
    appTo = 'findsuspect'
     
    request_str = fname_mobnum.split('-')
    filename = request_str[0]
    if len(request_str) == 2:
        mobnum = request_str[1]
    else:
        mobnum = None
    path_to_feat_vect = getPathToFeatVect(filename,appTo)
    predicModel = v2_SuspectClassify.initPredictModel(PATH_WEIGHTS,FEATURE_SHAPE,NB_CLASSES)
    npFeatVect = np.load(path_to_feat_vect)
    activity_result = v2_SuspectClassify.realTimePredict(npFeatVect,predicModel)
    results['act'] = activity_result
    if activity_result == 'SUSPECT':
        # Set Alarm ON
        results['alarm_stat'] = True
        if mobnum:
            response = notifyActivity_SMS(mobnum)
        else:
            response = None
    elif activity_result == 'NORMAL':
        # Clear/No Alarm
        results['alarm_stat'] = False
    return jsonify({'results':results})


@app.route("/sia/findshoplift/<fname>",methods=['GET'])
def SiaAppFindShoplift(fname):
    results = {'act':None,'alarm_stat':None}
    PATH_WEIGHTS = 'weights/shoplift/lstm-features.011-0.153.h5'
    FEATURE_SHAPE = (40,1280)
    NB_CLASSES = 2
    appTo = 'findshoplift'
    path_to_feat_vect = getPathToFeatVect(fname,appTo)
    predicModel = FindShoplifter.initPredictModel(PATH_WEIGHTS,FEATURE_SHAPE,NB_CLASSES)
    npFeatVect = np.load(path_to_feat_vect)
    activity_result = FindShoplifter.realTimePredict(npFeatVect,predicModel)
    results['act'] = activity_result
    if activity_result == 'SHOPLIFT':
        results['alarm_stat'] = True
    elif activity_result == 'NORMAL':
        results['alarm_stat'] = False
    return jsonify({'results':results})


if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8080)

