#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  IRecordVideo_v12.py
#  
#  Copyright 2019 AMAR P <amar.potdar@capgemini.com>
from picamera.array import PiRGBArray
from picamera import PiCamera

#from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input
from tensorflow.keras.layers import Dense, Flatten, Dropout
from tensorflow.keras.layers import LSTM
from tensorflow.keras.models import Sequential
from tensorflow.keras.optimizers import Adam, RMSprop
from tensorflow.keras.applications.mobilenet_v2 import MobileNetV2, preprocess_input

import numpy as np
import cv2

import time
from tqdm import tqdm
import operator
import os
#import matplotlib.pyplot as plt


import tensorflow as tf
tf.logging.set_verbosity(tf.logging.ERROR)

#=======================================================================
#All Constants
#=======================================================================
PATH_WEIGHTS = 'weights/lstm-features.011-0.295.h5'
FEATURE_SHAPE = (40,1280)
NB_CLASSES = 2

FRAME_LEN = 40
CamResolution=(640,480)

def initFeatureModel():
    """
    Build and Init Feature/Base Model, will be used for feature extraction from
    images
    """
    featureModel = MobileNetV2(weights='imagenet',
                             include_top=False,
                             pooling='avg')
    return featureModel
   
def extractFeature(model,img):
    """
    This will extract feature from the given frame using InceptionV3 as Base
    model
    """
    img = cv2.resize(img,(224,224),interpolation = cv2.INTER_CUBIC)
#    img = (img / 255.).astype(np.float32)
    x = np.expand_dims(img, axis=0)
    x = preprocess_input(x)
    # Get the prediction.
    features = model.predict(x)
    features = features[0]
    return features
    
def initPredictModel(pathPretrainedWeights,InputShape,NClasses):
    """
    Build and Initialize Prediction model
    """
    #Define model/network Architecture
    FinModel = Sequential()
    FinModel.add(LSTM(1280, return_sequences=False,
                   input_shape=InputShape,
                   activation='tanh',
                   recurrent_activation='sigmoid'))
    FinModel.add(Dense(512, activation='relu'))
    FinModel.add(Dropout(0.5))
    FinModel.add(Dense(NClasses, activation='softmax'))    
    #Add pretraied Weights
    FinModel.load_weights(pathPretrainedWeights)
    
    optimizer = Adam(lr=1e-5, decay=1e-6)
    FinModel.compile(loss='categorical_crossentropy', optimizer=optimizer,metrics=['accuracy'])
    return FinModel
    
def realTimePredict(npFeatVect,PredictModel):
    AllProbs = PredictModel.predict(np.expand_dims(npFeatVect, axis=0))      
    print_class_from_prediction(np.squeeze(AllProbs, axis=0))
    
def notifyActivity_SMS():
    import requests
    url = "https://www.fast2sms.com/dev/bulk"
    querystring = {"authorization":"17VQSGeXHPfNlcR4BnFdJvWATgoMq2wbaj6I0uKOpy3ki5hsCL2tfMjGa5lNLDYvWyheFXi0UuK3cr4x",
               "sender_id":"FSTSMS",
               "message":"Warning! Suspecious Activity@CAM-007",
               "language":"english",
               "route":"p",
               "numbers":"7798359389"} #Dr.Sampath 7798359389
    headers ={'cache-control': "no-cache"}
    response = requests.request("GET", url, headers=headers, params=querystring)
    #print(response.text)
    
def warnBuzzer():
    import RPi.GPIO as GPIO
    import time
    BUZZER_PIN = 8
    
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BOARD)
    GPIO.setup(BUZZER_PIN,GPIO.OUT,initial = GPIO.LOW)

    for _ in range(5):
        GPIO.output(BUZZER_PIN,GPIO.LOW)
        time.sleep(0.3) #300ms
        GPIO.output(BUZZER_PIN,GPIO.HIGH)
        time.sleep(0.3) #300ms
    GPIO.cleanup()


def print_class_from_prediction(predictions, nb_to_return=5):
    """Given a prediction, print the top classes."""
    # Get the prediction for each label.
    classes = ['normal','suspect']
    label_predictions = {}
    for i, label in enumerate(classes):
        label_predictions[label] = predictions[i]

    # Now sort them.
    sorted_lps = sorted(
        label_predictions.items(),
        key=operator.itemgetter(1),
        reverse=True
    )
    result = sorted_lps[0][0]
    result= result.upper()

    # And return the top N
    print('\n\n===========================================================')
    if result == 'SUSPECT':     
        print("\033[1;31;40m    0000  0   0  0000  0000   0000   0000  00000  \033[0;37;40m")
        print("\033[1;31;40m    0     0   0  0     0   0  0     0        0    \033[0;37;40m")
        print("\033[1;31;40m    0000  0   0  0000  0000   000   0        0    \033[0;37;40m")
        print("\033[1;31;40m       0  0   0     0  0      0     0        0    \033[0;37;40m")
        print("\033[1;31;40m    0000   000   0000  0      0000   0000    0    \033[0;37;40m")
        notifyActivity_SMS()
        warnBuzzer()
    elif result == 'NORMAL':
        print("\033[1;32;40m     000   0     0       00000  0000    0   0  0000  0     0       \033[0;37;40m")
        print("\033[1;32;40m    0   0  0     0         0    0       0   0  0     0     0       \033[0;37;40m")
        print("\033[1;32;40m    00000  0     0         0    0000    0 0 0  000   0     0       \033[0;37;40m")
        print("\033[1;32;40m    0   0  0     0         0       0    00 00  0     0     0       \033[0;37;40m")
        print("\033[1;32;40m    0   0  0000  0000    00000  0000    0   0  0000  0000  0000    \033[0;37;40m")
    print('===========================================================')
    #for i, class_prediction in enumerate(sorted_lps):
        #if i > nb_to_return - 1 or class_prediction[1] == 0.0:
            #break
        #print("%s: %.2f" % (class_prediction[0], class_prediction[1]))
        
        
def previewVideo():
    os.system('omxplayer --win 700,100,1020,340 action.avi')    
    #--win 800,100,1120,340 
                    

#=======================================================================
#Main Prog
#=======================================================================
#Load pre-trained Models
print('\nInitializing Model...')
featModel = initFeatureModel()

#=======================================================================
print('\nPreparing Camera...')
camera = PiCamera()
camera.resolution = CamResolution
camera.rotation = 180
camera.framerate = 4
rawCapture = PiRGBArray(camera,size=CamResolution)
time.sleep(0.2)

#=======================================================================
#Constants
PredicModelLoadedFlag = False
AllFrameArray=[]
featureVect=[]
frameNum = 0
print('Recording Video (0.0)...')

OutVideo = cv2.VideoWriter('action.avi',cv2.VideoWriter_fourcc(*'XVID'),4,(640,480))
pbar = tqdm(total=FRAME_LEN,leave=False,unit='frame')
start = time.time()
for frame in camera.capture_continuous(rawCapture,format='rgb',use_video_port=True):
    #print('Hey,I Am Watching (^.^)\n')
    if frameNum < FRAME_LEN:
        img = frame.array
        AllFrameArray.append(img)
        img = cv2.cvtColor(img,cv2.COLOR_RGB2BGR)
        OutVideo.write(img)
        rawCapture.truncate(0)
        frameNum += 1
        pbar.update(1)
        pbar.refresh()
    else:
        frameNum = 0
        rawCapture.truncate(0)
        print('Predicting (-.-).. \n\n')
        featureVect = [extractFeature(featModel,img) for img in AllFrameArray]
        npfeatureVect = np.array(featureVect)
        featureVect=[]
        AllFrameArray = []
        if PredicModelLoadedFlag == False:
            print('Initializing Deep Learning Model...')
            predicModel = initPredictModel(PATH_WEIGHTS,FEATURE_SHAPE,NB_CLASSES)
            PredicModelLoadedFlag = True
        realTimePredict(npfeatureVect,predicModel)
        #print('\n\nTime to 40 frame Extract + Predict = ', time.time()-start)
        previewVideo()
        OutVideo.release()
        OutVideo = cv2.VideoWriter('action.avi',cv2.VideoWriter_fourcc(*'XVID'),4,(640,480))
        pbar.n = 0
        frameNum = 0
               
