# -*- coding: utf-8 -*-
"""
File: pyvision.py
Description: pyvision class-implementation
Version: V2.0
Created on Thu Dec 27 14:57:11 2018
@author: apotdar

Robo State Machine Description:
    0: FND
    1: PCK
    2: PAT
    3: DRP
    4: INFO

ToDo:
    - Add Mark and Object Calc Dist functions

"""

#import multiprocessing as mp


from sklearn.neural_network import MLPClassifier
from joblib import load
import numpy as np
import cv2
import roboparam
import time
import logging

logger = logging.getLogger(__name__)
cons_handler = logging.StreamHandler()
cons_handler.setLevel(logging.DEBUG)
cons_handler.setFormatter('%(asctime)s-%(name)s-%(levelname)s-%(message)s')
logger.addHandler(cons_handler)

class pyvision():
    #ObjPickStat = False

    def __init__(self,InputImgPath=None,verbose=False,detector='BGR'):
        self.detector = detector
        self.RoboID = roboparam.MyID
        self.InputImgPath = InputImgPath
        self.brightness = roboparam.VisionPara[self.RoboID]['CameraBright']
        self.myMLP = load('ANN_robo.joblib')
        self.verbose = verbose
        self.setObjPickStatFlag(False)
        logger.debug('Init Done')

    def setObjPickStatFlag(self,FlagVal):
        self.ObjPickStat = FlagVal


    def getObjPickStatFlag(self):
        return self.ObjPickStat

#==============================================================================
    def setObjHSV(self,UpperHSV,LowerHSV):
        self.ObjUpperHSV = UpperHSV
        self.ObjLowerHSV = LowerHSV

    def getObjHSV(self):
        return np.vstack((self.ObjUpperHSV,self.ObjLowerHSV))

    def setMarkHSV(self,UpperHSV,LowerHSV):
        self.MarkUpperHSV = UpperHSV
        self.MarkLowerHSV = LowerHSV

    def getMarkHSV(self):
        return np.vstack((self.MarkUpperHSV,self.MarkLowerHSV)) 
    
#==============================================================================    
    def setObjBGR(self,UpperBGR,LowerBGR):
        self.ObjUpperBGR = UpperBGR
        self.ObjLowerBGR = LowerBGR

    def getObjBGR(self):
        return np.vstack((self.ObjUpperBGR,self.ObjLowerBGR))

    def setMarkBGR(self,UpperBGR,LowerBGR):
        self.MarkUpperBGR = UpperBGR
        self.MarkLowerBGR = LowerBGR

    def getMarkBGR(self):
        return np.vstack((self.MarkUpperBGR,self.MarkLowerBGR))    

#==============================================================================
    def DetectMark(self,InputImg):
        if self.detector == 'BGR':
            DetectVal = self.getMarkBGR()
            #For BGR Image space conversion isn't required
        if self.detector == 'HSV':
            DetectVal = self.getMarkHSV()
            InputImg = cv2.cvtColor(InputImg,cv2.COLOR_BGR2HSV)
        else:
            raise Exception("Marker Detector value isn\'t initialised to \'BGR\' or \'HSV\' ")
            logger.error("Marker Detector value isn\'t initialised")
        self.ImgHeight,self.ImgWidth = 480,640
        #print(InputImg.shape[:2])
        #Mark Detection ROIs
        CenterVal = self.ImgWidth / 2
        LowerCenterVal = CenterVal - (CenterVal*0.3) #20Percent Below Center in HoriDir
        UpperCenterVal = CenterVal + (CenterVal*0.3) #20Percent Above Center in HoriDir
        
        #Create Massk
        ColorMask = cv2.inRange(InputImg,DetectVal[1],DetectVal[0])
        # Some Morph Opertations
        Kernel = np.ones((5,5),"uint8")
        ColorMask = cv2.dilate(ColorMask,Kernel)
        # Find Contours
        #print("Find Markers In Image")
        MarkStats = dict(isMarkFound=False,MarkLoc=None,MarkDims=[])
        (_,contours,hierarchy)=cv2.findContours(ColorMask,
                                                cv2.RETR_TREE,
                                                cv2.CHAIN_APPROX_SIMPLE)
        if len(contours) ==  0:
            #pass
            MarkStats['isMarkFound'] = False
            logger.warning('Unable to find Marker in Image Data')
            #MarkStats['MarkLoc'] = None
        else:
            for marks in contours:
                MarkArea = cv2.contourArea(marks)
                if(MarkArea > 300):
                    x,y,w,h = cv2.boundingRect(marks)
                    RectDims=[x,y,w,h]
                    if len(RectDims)>0:
                        MarkStats['MarkDims']=RectDims
                        if (w > 190 and h > 220):
                            MarkStats['isMarkFound']=True
                            MarkStats['MarkLoc'] = 'B'
                        elif(x+w/2 < LowerCenterVal):
                            MarkStats['isMarkFound']=True
                            MarkStats['MarkLoc'] = 'L'
                            break
                        elif(x+w/2 > UpperCenterVal):
                            MarkStats['isMarkFound']=True
                            MarkStats['MarkLoc'] = 'R'
                            break
                        elif(x+w/2 > LowerCenterVal and x+w/2 < UpperCenterVal):
                            MarkStats['isMarkFound'] =True
                            MarkStats['MarkLoc'] = 'C'
                            break
                else:
                    #Mark Not Found
                    MarkStats['isMarkFound'] = False
                    logger.warning('Unable to find Marker in Image Data')
        #print(MarkStats)
        return MarkStats


    def DetectObject(self,InputImg):
        if self.detector == 'BGR':
            DetectVal = self.getObjBGR()
            #For BGR Image space conversion isn't required
        if self.detector == 'HSV':
            DetectVal = self.getObjHSV()        
            InputImg = cv2.cvtColor(InputImg,cv2.COLOR_BGR2HSV)
        else:
            raise Exception("Object Detector value isn\'t initialised to \'BGR\' or \'HSV\' ")            
            logger.error("Object Detector value isn\'t initialised")
        #Object Detection ROIs
        CenterVal = self.ImgWidth / 2
        LowerCenterVal = CenterVal - (CenterVal*0.2) #20Percent Below Center in HoriDir
        UpperCenterVal = CenterVal + (CenterVal*0.2) #20Percent Above Center in HoriDir
        
        #Create Massk
        ColorMask = cv2.inRange(InputImg,DetectVal[1],DetectVal[0])
        # Some Morph Opertations
        Kernel = np.ones((5,5),"uint8")
        ColorMask = cv2.dilate(ColorMask,Kernel)
        # Find Contours
        ObjStats = dict(isObjFound=False,ObjLoc=None,ObjDims=[])
        (_,contours,hierarchy)=cv2.findContours(ColorMask,
                                                cv2.RETR_TREE,
                                                cv2.CHAIN_APPROX_SIMPLE)
        if len(contours) ==  0:
            #pass
            ObjStats['isObjFound'] = False            
            #MarkStats['MarkLoc'] = None
        else:
            for obj in contours:
                ObjArea = cv2.contourArea(obj)
                if (ObjArea > 300):
                    x,y,w,h = cv2.boundingRect(obj)
                    RectDims=[x,y,w,h]
                    ObjThresh = abs(w-h)
                    if len(RectDims)>0:
                        if ObjThresh <= 13:
                            ObjStats['ObjDims']=RectDims
                            if(x+w/2 < LowerCenterVal):
                                ObjStats['isObjFound']=True
                                ObjStats['ObjLoc'] = 'L'
                                break
                            elif(x+w/2 > UpperCenterVal):
                                ObjStats['isObjFound']=True
                                ObjStats['ObjLoc'] = 'R'
                                break
                            elif(x+w/2 > LowerCenterVal and x+w/2 < UpperCenterVal):
                                ObjStats['isObjFound'] =True
                                ObjStats['ObjLoc'] = 'C'
                                break
                else:
                    #Object Not Found
                    ObjStats['isObjFound'] = False
        #print(ObjStats)
        return ObjStats

    def getAllStats(self):
        if self.verbose == True:
            InputImg = cv2.imread(self.InputImgPath)
        else:
            import pycamera
            camcls = pycamera.initPiCamera()
            InputImg = pycamera.capturePic(camcls,self.brightness)
            #InputImg = cv2.imread('/home/pi/Documents/PHASE2/v2/img/1.jpg')
        MarkStat = self.DetectMark(InputImg)
        ObjStat = self.DetectObject(InputImg)
        AllStat = {**MarkStat,**ObjStat}
        #Queue.put(AllStat)
        return AllStat

#===============================================================================
    def MarkToCamDist(self,MarkDims):
        #Define Related Constantss
        CamFocLen =  68             #mm
        MarkRealWidth = 700         #mm
        MarkPxlWidth = MarkDims[2]  #Pixels
        distance = (MarkRealWidth * CamFocLen) / (MarkPxlWidth)
        return round(distance)

    def ObjToCamDist(self,ObjDims):
        #Define Related Constants
        CamFocLen =  68             #mm
        ObjRealWidth = 400          #mm
        ObjPxlWidth = ObjDims[2]    #Pixels
        distance = (ObjRealWidth * CamFocLen) / (ObjPxlWidth)
        return round(distance)

#===============================================================================
    def predictRoboState(self,Queue):
        AllStats = self.getAllStats()
        #print("\n\nCurrent Data=",AllStats)
        ObjFoundStat = AllStats['isObjFound']
        MarkFoundStat = AllStats['isMarkFound']
        PickStat = self.getObjPickStatFlag()
        myMLP = self.myMLP
        resultState = myMLP.predict([[PickStat, MarkFoundStat, ObjFoundStat]])
        #print("Predicated State = ", resultState)
        AllStats['MachineState'] = resultState
        print("\n\nFinal Data =", AllStats)
        Queue.put(AllStats)
        time.sleep(0.5)


    def run_pyvision(self,Queue):
        while True:
            self.predictRoboState(Queue)
            time.sleep(0.2)


#==============================================================================
def main():
    from threading import Thread
    from queue import Queue
    import roboparam


    RoboID = 'R111'
    q_out = Queue()

    mivis = pyvision(InputImgPath='img/Green1.jpg')
    mivis.setMarkHSV(roboparam.VisionPara[RoboID]['MarkColrUL'],
                     roboparam.VisionPara[RoboID]['MarkColrLL'])

    mivis.setObjHSV(roboparam.VisionPara[RoboID]['ObjColrUL'],
                    roboparam.VisionPara[RoboID]['ObjColrLL'])

    mivis.predictRoboState(q_out)


#    visionThread = Thread(target=mivis.predictRoboState, args=(q_out,))
#    visionThread.start()


    return

if (__name__ == "__main__"):
    main()




