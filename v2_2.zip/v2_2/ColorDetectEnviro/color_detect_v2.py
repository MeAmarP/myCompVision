# -*- coding: utf-8 -*-
"""
Created on Sat Nov 24 15:05:33 2018

@author: apotdar
"""

import time
import numpy as np
import cv2
#import matplotlib.pyplot as plt
#COLOR = [[LOWER Vals],[UPPER Vals]]
Blue = [[99,90,75],[136,124,104]] #Working
Orange = [[71,100,141],[100,141,194]] #Working
Green = [[71,100,71],[104,150,101]]


def detectColorObj(InputImg,ColorRange):
    ColorLower = np.array(ColorRange[0],dtype=np.uint8) 
    ColorUpper = np.array(ColorRange[1],dtype=np.uint8)
    
    start = time.time() # Run Timer
    height,width = InputImg.shape[:2]
    #MainImgHSV = cv2.cvtColor(MainImg,cv2.COLOR_BGR2HLS)

    Mask=cv2.inRange(InputImg,ColorLower,ColorUpper)
    Kernel = np.ones((5,5),"uint8")

    Mask = cv2.dilate(Mask,Kernel)
    #ImgOut = cv2.bitwise_and(MainImg,MainImg,mask=Mask).astype(np.uint8)

# Find Contours
    (_,contours,hierarchy)=cv2.findContours(Mask,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

    for pic, contour in enumerate(contours):
        area = cv2.contourArea(contour)
    
        if(area>300):
            x,y,w,h = cv2.boundingRect(contour)
            if(h>w):
                InputImg = cv2.rectangle(InputImg,(x,y),(x+w,y+h),(0,0,255),2)
                cv2.putText(InputImg,"Marker",(x,y),cv2.FONT_HERSHEY_SIMPLEX,0.7,(255,0,0))
        
    end = time.time() - start 
    print('Total Exec Time: ', end)
    
    return InputImg

if __name__== "__main__":
    ImgPath = "Pics_ironlab/G9.jpg"
    MainImg = cv2.imread(ImgPath)
    OutImg = detectColorObj(MainImg,Green)
#    plt.title(ImgPath)
#    plt.imshow(OutImg)
    cv2.imshow('Result',OutImg)
    cv2.waitKey(0)