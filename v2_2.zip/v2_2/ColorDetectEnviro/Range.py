import pandas as pd
import numpy as np
from pandas import ExcelWriter
import glob
import cv2

def bgr_fun(path,entered_pct,entered_range):
    diff1 = diff2 = diff3 = []  
    Rmin1 = Rmin2 = Rmin3 = []
    Rmax1 = Rmax2 = Rmax3 = []
    acc1  = acc2  = acc3  = []
#------------------------------------------------------------------------------    
    Images = glob.glob(''.join([path,'*.jpg']))

    for i in Images:
        InputImg = cv2.imread(i)
        ImgBGR = np.vstack((InputImg[:,:,0].flatten(),
                            InputImg[:,:,1].flatten(),
                            InputImg[:,:,2].flatten()
                            ))
        np.savetxt(i+'ImgBGR.csv', ImgBGR.T, delimiter=',', fmt='%u')
#------------------------------------------------------------------------------
    csvfiles = glob.glob(''.join([path,'*.csv']))
    for i in csvfiles:
        bgr = pd.read_csv(i,  names = ('Blue','Green','Red'))
        
        for colors in ('Blue','Green','Red'):
            hist = np.histogram(bgr[colors],bins=15)
            count = np.ndarray.tolist(hist[0])
            val1 = np.ndarray.tolist(hist[1][0:15])
            val2 = np.ndarray.tolist(hist[1][1:16])
            n_val = pd.DataFrame({'r1':val1,'r2':val2,'count':count})
            n_val['pct']= n_val['count']*100/(n_val['count'].sum())
            
            max_nval =  n_val.loc[(n_val['pct']==max(n_val['pct'])),:]
            max_nval1 = max_nval.loc[(max_nval['r1'] == min(max_nval['r1'])),:].reset_index()
            
            less_than = n_val[n_val.index < int(min(max_nval.index.values))]
            less_than = less_than.sort_index(ascending=False)
            less_than.reset_index(inplace=True)
    
            greater_than = n_val[n_val.index > int(min(max_nval.index.values))]
            greater_than.reset_index(inplace=True)

            pctr = pd.concat([max_nval1,greater_than,less_than]).sort_index()
            pctr.reset_index(inplace=True)
        
            for j in range(0,(len(pctr))):
                if(((max(pctr['r2'][:j+1]) - min(pctr['r1'][:j+1])) < entered_range) and (pctr['pct'][j] < entered_pct)):
                    diff = round((max(pctr['r2'][:j+1]) - min(pctr['r1'][:j+1])),2)
                    acc  = round((sum(pctr['pct'][(0):(j+1)])),2)
                    Rmin = round((min(pctr['r1'][:j+1])),2)
                    Rmax = round((max(pctr['r2'][:j+1])),2)
                
            if(colors == 'Red'):
                diff1 = np.append(diff1,diff)
                acc1   = np.append(acc1,acc)
                Rmin1   = np.append(Rmin1,Rmin)
                Rmax1   = np.append(Rmax1,Rmax)
            elif(colors == 'Green'):
                diff2 = np.append(diff2,diff)
                acc2   = np.append(acc2,acc)
                Rmin2   = np.append(Rmin2,Rmin)
                Rmax2   = np.append(Rmax2,Rmax)
            elif(colors == 'Blue'):
                diff3 = np.append(diff3,diff)
                acc3   = np.append(acc3,acc)
                Rmin3   = np.append(Rmin3,Rmin)
                Rmax3   = np.append(Rmax3,Rmax)

    accr = ','.join([str(min(acc1)),str(max(acc1))])
    acc1   = np.append(acc1,accr)
    diff1  = np.append(diff1,(max(Rmax1)-min(Rmin1)))
    Rmin1  = np.append(Rmin1,min(Rmin1))
    Rmax1   = np.append(Rmax1,max(Rmax1))
    BGR_red = {"Range":diff1,"R-begin":Rmin1,"R-end":Rmax1,"Accuracy":acc1}
    BGR_red = pd.DataFrame(BGR_red)
    print('Range for Red  :',(round(max(BGR_red['R-end'][0:(len(BGR_red)-1)])) - round(min(BGR_red['R-begin'][0:(len(BGR_red)-1)]))),
      ',Range Begin:',round(min(BGR_red['R-begin'][0:(len(BGR_red)-1)])),
      ',Range end  :',round(max(BGR_red['R-end'][0:(len(BGR_red)-1)])),
      ',Accuracy(min,max):',BGR_red['Accuracy'][-1:])

    accg = ','.join([str(min(acc2)),str(max(acc2))])
    acc2   = np.append(acc2,accg)
    diff2  = np.append(diff2,(max(Rmax2)-min(Rmin2)))
    Rmin2  = np.append(Rmin2,min(Rmin2))
    Rmax2   = np.append(Rmax2,max(Rmax2))
    BGR_green = {"Range":diff2,"R-begin":Rmin2,"R-end":Rmax2,"Accuracy":acc2}
    BGR_green = pd.DataFrame(BGR_green)
    print('Range for Green  :',(round(max(BGR_green['R-end'][0:(len(BGR_green)-1)])) - round(min(BGR_green['R-begin'][0:(len(BGR_green)-1)]))),
      ',Range Begin:',round(min(BGR_green['R-begin'][0:(len(BGR_green)-1)])),
      ',Range end  :',round(max(BGR_green['R-end'][0:(len(BGR_green)-1)])),
      ',Accuracy(min,max):',BGR_green['Accuracy'][-1:])

    accb = ','.join([str(min(acc3)),str(max(acc3))])
    acc3   = np.append(acc3,accb)
    diff3  = np.append(diff3,(max(Rmax3)-min(Rmin3)))
    Rmin3  = np.append(Rmin3,min(Rmin3))
    Rmax3   = np.append(Rmax3,max(Rmax3))
    BGR_blue = {"Range":diff3,"R-begin":Rmin3,"R-end":Rmax3,"Accuracy":acc3}
    BGR_blue = pd.DataFrame(BGR_blue)
    print('Range for Blue  :',(round(max(BGR_blue['R-end'][0:(len(BGR_blue)-1)])) - round(min(BGR_blue['R-begin'][0:(len(BGR_blue)-1)]))),
      ',Range Begin:',round(min(BGR_blue['R-begin'][0:(len(BGR_blue)-1)])),
      ',Range end  :',round(max(BGR_blue['R-end'][0:(len(BGR_blue)-1)])),
      ',Accuracy(min,max):',BGR_blue['Accuracy'][-1:])

    min_RGB = [round(Rmin3[-1]),round(Rmin2[-1]),round(Rmin1[-1])]
    max_RGB = [round(Rmax3[-1]),round(Rmax2[-1]),round(Rmax1[-1])]
    Range_RGB = [round((Rmax3[-1]-Rmin3[-1])),round((Rmax2[-1]-Rmin2[-1])),round((Rmax1[-1]-Rmin1[-1]))]
    res = {"min":min_RGB,'max':max_RGB,'Range':Range_RGB}
    res = pd.DataFrame(res,index = ['B','G','R']) 
    
    writer = ExcelWriter(''.join([path,'Res.xlsx']))    
    BGR_blue.to_excel(writer,'BLUE')
    BGR_green.to_excel(writer,'GREEN')
    BGR_red.to_excel(writer,'RED')
    res.to_excel(writer,'RESULTS')
    writer.save()

if __name__ == "__main__":
    bgr_fun()